//
//  ViewController.m
//  超级猜图
//
//  Created by 石子涵 on 2020/1/29.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

//改变状态栏的颜se
-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    //1添加label
    UILabel *lblTitle = [[UILabel alloc] init];
    //2设置label属性
    lblTitle.backgroundColor = [UIColor whiteColor];
    CGFloat titX = self.view.frame.size.width/4;
    CGFloat titY = 
    //3将label添加到屏幕上
    
}


@end
