//
//  ViewController.m
//  寒假作业定时器
//
//  Created by 石子涵 on 2020/1/31.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "ViewController.h"
#import "Masonry.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor greenColor];
    UIImageView *imgViw1 = [[UIImageView alloc] init];
    imgViw1.image = [UIImage imageNamed:@"NL"];
    [self.view addSubview:imgViw1];
    //制造约束
//    [imgViw1 mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.equalTo(self.view.mas_top).offset(50);
//        make.left.equalTo(self.view.mas_left).offset(20);
//        make.right.equalTo(self.view.mas_right).offset(-20);
//        make.bottom.equalTo(self.view.mas_bottom).offset(-50);
//    }];
    //简化：
//    [imgViw1 mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.offset(50);
//        make.left.offset(20);
//        make.right.offset(-20);
//        make.bottom.offset(-50);
//    }];
    //再简化
    [imgViw1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.insets(UIEdgeInsetsMake(50, 20, 20, 50));

    }];
    
//    UIView *viw = [[UIView alloc] init];
//    viw.backgroundColor = [UIColor redColor];
//    //添加约束
//    [viw mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.width.equalTo(@100);
//        make.height.equalTo(@100);
//       
//    }];
//
//    [self.view addSubview:viw];
}


@end
