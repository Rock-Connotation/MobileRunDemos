//
//  ViewController.m
//  图片浏览器
//
//  Created by 石子涵 on 2020/1/20.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
//@property (nonatomic, strong) NSArray *pic;
//@property (weak, nonatomic) IBOutlet UILabel *numberLable;
//@property (weak, nonatomic) IBOutlet UIButton *nextBtn;
//@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
////@property (weak, nonatomic) IBOutlet UIButton *preBtn;
//@property (weak, nonatomic) IBOutlet UIImageView *image;
////- (IBAction)next;
////- (IBAction)pre;
//@property (nonatomic , assign) int index;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//    self.index = - 1;
//    [self next];
}
//重写pic属性的get方法
//-(NSArray *)pic{
//    //懒加载获取plist中的数据
//    if(_pic == nil){   //懒加载
//    NSString *path = [[NSBundle mainBundle] pathForResource:@"pic.plist" ofType:@"nil"];
//    NSArray *array = [NSArray arrayWithContentsOfFile:path];
//        _pic = array;
//    }
//    return _pic;
//}
////设置控件数据
//-(void)setDate{
//    //从数组中获取当前索引对应下的数据
//    NSDictionary *dic = self.pic[self.index];
//    //把获取到的数据拿给界面上的控件
//    self.numberLable.text = [NSString stringWithFormat:@"%d/%ld",self.index + 1 ,self.pic.count];//显示个数
//    self.image.image = [UIImage imageNamed:dic[@"icon"]]; //显示图片
//    self.titleLabel.text = dic[@"title"]; //显示标题文字
//    //设置按钮可用不可用
//    self.nextBtn.enabled = (self.index != (self.pic.count - 1));
//    self.preBtn.enabled = (self.index != 0);
//}
//
//- (IBAction)next {
//    self.index++;
//    [self setDate];
//}
//
//- (IBAction)pre {
//    self.index--;
//    [self setDate];
//}
@end
