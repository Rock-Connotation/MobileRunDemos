//
//  ViewController.m
//  第二阶段学习day--02--展示英雄数据
//
//  Created by 石子涵 on 2020/2/25.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "ViewController.h"
#import "SZHHeros.h"
@interface ViewController ()<UITableViewDataSource,UITableViewDelegate,UIAlertViewDelegate>
@property (nonatomic, strong) NSArray *heros;
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
#pragma mark -懒加载数据
-(NSArray *)heros{
    if (_heros == nil) {
        //获取plist文件的路径
        NSString *path = [[NSBundle mainBundle] pathForResource:@"heros.plist" ofType:nil];
        //根据文件路径获取plist文件
        NSArray *arrryDicts = [NSArray arrayWithContentsOfFile:path];
        
        NSMutableArray *arryModels = [NSMutableArray new];
        for (NSDictionary *dic in arrryDicts) {
            SZHHeros *model = [SZHHeros heroWithDict:dic];
            [arryModels addObject:model];
        }
        _heros = arryModels;
    }
    return _heros;
}

#pragma mark -数据源方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.heros.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    //1获取模型数据
    SZHHeros *hero = self.heros[indexPath.row];
    
    
    //2创建单元格
    
    
    //不是使用复用池时的写法
//    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil];
    
    //使用复用池
// 因为每次都创建一个单元格效率比较低, 所以要对单元格进行重用。
// 单元格重用的基本思路就是:
// 1> 在创建单元格的时候指定一个"重用ID"
// 2> 当需要一个新的单元格的时候, 先去"缓存池"中根据"重用ID"去查找是否有可用的单元格
// ** 如果有, 则直接从缓存池中取出这个单元格, 进行使用（修改这个单元格中显示的数据、样式）
// ** 如果没有需要的单元格, 此时只能重新创建件一个单元格了。
    //声明一个重用ID
     static NSString *ID = @"hero_cell"; //因为id会经常使用，所以用static将其变为全局变量，提高效率
    //根据这个重用ID去“复用池”里查找
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    //如果“复用池“里没有这样的单元格，就创建y
    if (cell == nil) {
    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:ID];
    }
       
    
    //3将模型数据给单元格
    cell.textLabel.text = hero.name;
    cell.detailTextLabel.text = hero.intro;
    cell.imageView.image = [UIImage imageNamed:hero.icon];
    //设置单元格右边的小箭头
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    //自定义单元格右边的东西
   // cell.accessoryView = [[UISwitch alloc] init];
    
    //4返回单元格
    return cell;
}
#pragma mark -tableView代理方法
//监听被选中的方法

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    //获取当前被选中的英雄的名字
    SZHHeros *hero = self.heros[indexPath.section];
    //创建一个对话框对象
    UIAlertController *alertViewController = [UIAlertController alertControllerWithTitle:@"编辑英雄" message:nil preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
    }];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [alertViewController dismissViewControllerAnimated:YES completion:nil];
        UITextField *textFiled = alertViewController.textFields[0];
        textFiled.text = hero.name;
    }];
        [alertViewController addAction:cancelAction];
        [alertViewController addAction:okAction];
        [alertViewController addTextFieldWithConfigurationHandler:nil];
        [self presentViewController:alertViewController animated:YES completion:nil];
    };
   
//    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"输入学员卡号" message:nil preferredStyle:UIAlertControllerStyleAlert];
//
//    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
//    }];
//    WS(weakSelf)
//    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
//        //
//        [alertController dismissViewControllerAnimated:YES completion:nil];
//        UITextField *textField = alertController.textFields[0];
//        weakSelf.perInfoModel.cadetCardNumber = textField.text;
//        [weakSelf tableViewFerfreshCell:indexPath.row section:indexPath.section];
//        [weakSelf updateServerCadetCardNumber:weakSelf.perInfoModel.cadetCardNumber];
//    }];
//
//    [alertController addAction:cancelAction];
//    [alertController addAction:okAction];
//    [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
//        textField.placeholder = @"国家继教网卡号";
//    }];
//    [self presentViewController:alertController animated:YES completion:nil];

    
    
    
    
    
    
    
    
    
    
    
//    //把当前的索引保存到alertView的tag值当中
//    alertView.tag = indexPath.row;
//    // 修改UIAlertViwe的样式, 显示出一个文本框来
//    alertView.alertViewStyle = UIAlertViewStylePlainTextInput;
//    //获取那个文本框，并将文字设置为hero的n名字
//    [alertView textFieldAtIndex:0].text = hero.name;
//    //显示对话框
//    [alertView show];

//// 当点击了alertview上的按钮的时候会执行这个方法

@end
