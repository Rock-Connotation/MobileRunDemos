//
//  SZHHeros.m
//  第二阶段学习day--02--展示英雄数据
//
//  Created by 石子涵 on 2020/2/25.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "SZHHeros.h"

@implementation SZHHeros
-(instancetype)initWithDict:(NSDictionary *)dict{
    if (self = [super init]) {
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}
+(instancetype)heroWithDict:(NSDictionary *)dict{
    return [[self alloc] initWithDict:dict];
}

@end
