//
//  ViewController.m
//  导航控制器
//
//  Created by 石子涵 on 2020/2/29.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "ViewController.h"
#import "RootViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view
    self.navigationController.navigationBar.hidden = YES;
    UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(100, 100, 100, 100)];
    button.backgroundColor = [UIColor blackColor];
    [button addTarget:self action:@selector(changeView) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
}
- (void)changeView{
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController: [[RootViewController alloc] init]];
    [self presentViewController:nav animated:YES completion:nil];
}

@end
