//
//  RootViewController.m
//  导航控制器
//
//  Created by 石子涵 on 2020/2/29.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "RootViewController.h"
#import "TwoViewController.h"
#import "ViewController.h"
@interface RootViewController ()

@end

@implementation RootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"root"  ;
    [self.navigationController setNavigationBarHidden:YES];
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(200, 200, 50, 50)];
       btn.backgroundColor = [UIColor blackColor];
       [btn addTarget:self action:@selector(changeView2) forControlEvents:UIControlEventTouchUpInside];
       [self.view addSubview:btn];
    
    UIButton *btn2 = [[UIButton alloc] initWithFrame:CGRectMake(300, 300, 100, 100)];
          btn2.backgroundColor = [UIColor whiteColor];
          [btn2 addTarget:self action:@selector(changeView3) forControlEvents:UIControlEventTouchUpInside];
          [self.view addSubview:btn2];
    
}
- (void)changeView2{
    TwoViewController *con = [[TwoViewController alloc] init];
    [self.navigationController pushViewController:con animated:YES];
    self.view.backgroundColor = [UIColor greenColor];
}
- (void)changeView3{
    [self.navigationController popViewControllerAnimated:YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
