//
//  ViewController.m
//  导航控制器测试
//
//  Created by 石子涵 on 2020/2/29.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "ViewController.h"
#import "twoViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
       //创建根视图控制器
       ViewController* rootVC = [[ViewController alloc] init];
       //创建UINavigationController，将根视图控制器作为它的根视图
       UINavigationController* navVC = [[UINavigationController alloc] initWithRootViewController:rootVC];
    self.navigationController.navigationBar.hidden = YES;
    self.navigationController.navigationBarHidden = YES;
      UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(100, 100, 100, 100)];
      button.backgroundColor = [UIColor blackColor];
      [button addTarget:self action:@selector(changeView) forControlEvents:UIControlEventTouchUpInside];
      [self.view addSubview:button];
    
}
- (void)changeView{
    twoViewController *tvc = [[twoViewController alloc] init];
    [self.navigationController pushViewController:tvc animated:YES];
}

@end
