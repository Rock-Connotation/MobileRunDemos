//
//  SZHGoods.m
//  第二阶段学习day--04--团购
//
//  Created by 石子涵 on 2020/2/27.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "SZHGoods.h"

@implementation SZHGoods
- (instancetype)initWithDict:(NSDictionary *)dict{
    if (self = [super init]) {
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}
+ (instancetype)goodsWithDict:(NSDictionary *)dict{
    return [[self alloc] initWithDict:dict];
}
@end
