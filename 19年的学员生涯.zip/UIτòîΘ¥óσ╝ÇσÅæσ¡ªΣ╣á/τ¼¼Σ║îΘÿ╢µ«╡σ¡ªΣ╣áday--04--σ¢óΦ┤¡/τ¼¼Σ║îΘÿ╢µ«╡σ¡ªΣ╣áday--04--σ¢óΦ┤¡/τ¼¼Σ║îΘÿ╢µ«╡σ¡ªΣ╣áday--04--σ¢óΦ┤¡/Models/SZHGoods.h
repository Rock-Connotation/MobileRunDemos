//
//  SZHGoods.h
//  第二阶段学习day--04--团购
//
//  Created by 石子涵 on 2020/2/27.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SZHGoods : NSObject
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *icon;
@property (nonatomic, strong) NSString *buyCount;
@property (nonatomic, strong) NSString *price;

- (instancetype)initWithDict:(NSDictionary *)dict;
+ (instancetype)goodsWithDict:(NSDictionary *)dict;
@end

NS_ASSUME_NONNULL_END
