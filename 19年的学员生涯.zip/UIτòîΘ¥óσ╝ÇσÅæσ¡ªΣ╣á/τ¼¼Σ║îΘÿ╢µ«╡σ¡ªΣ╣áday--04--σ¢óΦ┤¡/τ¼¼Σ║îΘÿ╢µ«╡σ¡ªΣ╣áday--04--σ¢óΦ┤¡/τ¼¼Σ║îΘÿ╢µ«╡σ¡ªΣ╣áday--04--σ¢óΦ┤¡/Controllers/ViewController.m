//
//  ViewController.m
//  第二阶段学习day--04--团购
//
//  Created by 石子涵 on 2020/2/27.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "ViewController.h"
#import "SZHGoods.h"
#import "SZHGoodsCell.h"
@interface ViewController ()<UITableViewDataSource>
@property (nonatomic, strong) NSArray *goods;
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation ViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.tableView.rowHeight = 44;
}

#pragma mark -隐藏状态栏
- (BOOL)prefersStatusBarHidden{
    return YES;
}

#pragma mark -懒加载数据
- (NSArray *)goods{
    if (_goods == nil) {
        NSString *path = [[NSBundle mainBundle] pathForResource:@"tgs.plist" ofType:nil];
        NSArray *arrayDict = [NSArray arrayWithContentsOfFile:path];
        NSMutableArray *arrayModels = [NSMutableArray new];
        for (NSDictionary *dict in arrayDict) {
            SZHGoods *model = [SZHGoods goodsWithDict:dict];
            [arrayModels addObject:model];
        }
        _goods = arrayModels;
    }
    return _goods;
}

#pragma mark -数据源方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.goods.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    //1获取模型数据
    SZHGoods *good = self.goods[indexPath.row];
//    //2j创建单元格
//   static NSString *ID = @"good_cell";
//    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
//    if (cell == nil) {
//        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:ID];
//    }
//
//    //3将数据设置给单元格
//    cell.textLabel.text = good.title;
//    cell.imageView.image = [UIImage imageNamed:good.icon];
//    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@     %@人已购买", good.price, good.buyCount ];
    
    
//通过xib方式来实现2、3步骤
    //2创建单元格
    //通过一个类方法创建单元格，同样也是为了避免步骤3中出现的问题
      SZHGoodsCell *cell =  [SZHGoodsCell goodsCellWithTableView:tableView];
//3将数据给单元格
    // 在控制器中直接为cell的每个子控件赋值数据造成的问题：
    // 1. 控制器强依赖于Cell, 一旦cell内部的子控件发生了变化, 那么控制器中的代码也得改（这就造成了紧耦合）
    // 2. cell的封装不够完整, 凡是用到这个cell的地方, 每次都要编写为cell的子控件依次赋值的语句，比如：cell.xxx = model.title;
    // 3. 解决: 直接把模型传递给自定义Cell, 然后在自定义cell内部解析model中的数据赋值给自定义cell内部的子控件。
    cell.goods = good;
    
    //4返回单元格
    return cell;
}


@end
