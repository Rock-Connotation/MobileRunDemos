//
//  SZHGoodsCell.m
//  第二阶段学习day--04--团购
//
//  Created by 石子涵 on 2020/2/27.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "SZHGoodsCell.h"
#import "SZHGoods.h"
@interface SZHGoodsCell()
@property (weak, nonatomic) IBOutlet UIImageView *imgViewIcon;
@property (weak, nonatomic) IBOutlet UILabel *lblTitle;
@property (weak, nonatomic) IBOutlet UILabel *lblPrice;
@property (weak, nonatomic) IBOutlet UILabel *lblBuyCount;



@end

@implementation SZHGoodsCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setGoods:(SZHGoods *)goods{
    _goods = goods;
    //把模型的数据赋值给子控件
    self.imageView.image = [UIImage imageNamed:goods.icon];
    self.lblTitle.text = goods.title;
    self.lblPrice.text = [NSString stringWithFormat:@"￥ %@", goods.price];
       self.lblBuyCount.text = [NSString stringWithFormat:@"%@ 人已购买", goods.buyCount];
}


+ (instancetype)goodsCellWithTableView:(UITableView *)tableview{
   static NSString *ID= @"good_cell";
    SZHGoodsCell *cell = [tableview dequeueReusableCellWithIdentifier:ID];
    if (cell == nil) {
        //注意；通过xib自定义cell的话，自定义的cell的复用标识在xib中设置
        cell = [[[NSBundle mainBundle] loadNibNamed:@"SZHGoodsCell" owner:nil options:nil] firstObject];
    }
    return cell;
}
@end
