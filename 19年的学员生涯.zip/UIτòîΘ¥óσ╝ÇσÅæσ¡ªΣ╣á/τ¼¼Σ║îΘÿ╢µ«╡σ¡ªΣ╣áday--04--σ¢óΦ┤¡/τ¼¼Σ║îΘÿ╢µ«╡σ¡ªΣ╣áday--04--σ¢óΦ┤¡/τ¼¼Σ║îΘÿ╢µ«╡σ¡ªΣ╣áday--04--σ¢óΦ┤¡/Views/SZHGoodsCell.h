//
//  SZHGoodsCell.h
//  第二阶段学习day--04--团购
//
//  Created by 石子涵 on 2020/2/27.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class SZHGoods;
@interface SZHGoodsCell : UITableViewCell
@property (nonatomic, strong) SZHGoods *goods;
+ (instancetype)goodsCellWithTableView:(UITableView *)tableview;
@end

NS_ASSUME_NONNULL_END
