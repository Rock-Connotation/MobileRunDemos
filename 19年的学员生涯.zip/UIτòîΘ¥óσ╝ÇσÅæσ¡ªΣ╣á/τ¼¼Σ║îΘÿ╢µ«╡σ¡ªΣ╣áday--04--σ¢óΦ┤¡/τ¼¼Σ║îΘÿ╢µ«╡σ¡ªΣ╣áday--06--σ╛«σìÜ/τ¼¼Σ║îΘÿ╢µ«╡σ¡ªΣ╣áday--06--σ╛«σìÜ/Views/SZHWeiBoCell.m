//
//  SZHWeiBoCell.m
//  第二阶段学习day--06--微博
//
//  Created by 石子涵 on 2020/2/29.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "SZHWeiBoCell.h"
#import "SZHWeiBo.h"
@interface SZHWeiBoCell()
@property (nonatomic, weak)UIImageView *imgViewIcon;
@property (nonatomic, weak)UIImageView *imgViewVip;
@property (nonatomic, weak)UIImageView *imgPicture;
@property (nonatomic, weak)UILabel *lblText;
@property (nonatomic, weak)UILabel *lblNickName;

@end

@implementation SZHWeiBoCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
#pragma mark -重写cell的initWithStyle方法
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        //创建五个控件
        //1头像
        UIImageView *imgViewIcon = [[UIImageView alloc] init];
        [self.contentView addSubview:imgViewIcon];
        self.imgViewIcon = imgViewIcon;
        
        //2昵称
        UILabel *lblNickName = [[UILabel alloc] init];
        [self.contentView addSubview:lblNickName];
        self.lblNickName = lblNickName;
        
        //3正文
        UILabel *lblText = [[UILabel alloc] init];
        [self.contentView addSubview:lblText];
        self.lblText = lblText;
        
        //4vip
        UIImageView *imgViewVip = [[UIImageView alloc] init];
        imgViewVip.image = [UIImage imageNamed:@"vip"]; 
        [self.contentView addSubview:imgViewVip];
        self.imgViewVip = imgViewVip;
        
        //5配图
        UIImageView *imgPicture = [[UIImageView alloc] init];
        [self.contentView addSubview:imgPicture];
        self.imgPicture = imgPicture;
    }
    return self;
}

#pragma mark -重写weibo属性的set方法
- (void)setWeibo:(SZHWeiBo *)weibo{
    //1给五个控件设置数据
    [self settingDate];
    
    //2给五个控件设置frame
    [self settingFrame];
    
}
//设置数据的方法
- (void)settingDate{
    SZHWeiBo *model = self.weibo;
    //1头像
    self.imgViewIcon.image = [UIImage imageNamed:model.icon];
    
        //2昵称
    self.lblNickName.text = model.name;
    
    //3配图
    if (model.picture) {
        //有配图
        //如果model.picture为nil，执行下面这句话会报异常
        self.imgPicture.image = [UIImage imageNamed:model.picture];
        //不隐藏图片框
        self.imgPicture.hidden = NO;
    }else{
        self.imgPicture.hidden = YES;
    }
    
    //4正文
    self.lblText.text = model.text;
    
    //5vip
    if (model.isVip) {
        //显示图片框
        self.imgViewVip.hidden = NO;
    }else{
        //不显示图片框
        self.imgViewVip.hidden = YES;
    }
    
}
//设置frame的方法
- (void)settingFrame{
    //提取统一的间距
    CGFloat margin = 10;
    //1头像
    CGFloat iconW = 35;
    CGFloat iconH = 35;
    CGFloat iconX = margin;
    CGFloat iconY = margin;
    self.imgViewIcon.frame = CGRectMake(iconX, iconY, iconW, iconH);
        //2昵称
  
    
    //3配图
   
    
    //4正文
   
    
    //5vip
}
@end
