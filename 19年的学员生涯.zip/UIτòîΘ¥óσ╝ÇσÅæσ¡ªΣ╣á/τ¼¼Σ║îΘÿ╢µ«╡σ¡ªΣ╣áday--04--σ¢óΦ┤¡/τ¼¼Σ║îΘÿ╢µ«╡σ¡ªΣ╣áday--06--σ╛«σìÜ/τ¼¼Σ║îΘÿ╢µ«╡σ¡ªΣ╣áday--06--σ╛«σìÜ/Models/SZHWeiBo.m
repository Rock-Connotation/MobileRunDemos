//
//  SZHWeiBo.m
//  第二阶段学习day--06--微博
//
//  Created by 石子涵 on 2020/2/29.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "SZHWeiBo.h"

@implementation SZHWeiBo
- (instancetype)initWithDict:(NSDictionary *)dict{
    if (self = [super init]) {
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}

+ (instancetype)weiboWitnDict:(NSDictionary *)dict{
    return [[self alloc] initWithDict:dict];
}
@end
