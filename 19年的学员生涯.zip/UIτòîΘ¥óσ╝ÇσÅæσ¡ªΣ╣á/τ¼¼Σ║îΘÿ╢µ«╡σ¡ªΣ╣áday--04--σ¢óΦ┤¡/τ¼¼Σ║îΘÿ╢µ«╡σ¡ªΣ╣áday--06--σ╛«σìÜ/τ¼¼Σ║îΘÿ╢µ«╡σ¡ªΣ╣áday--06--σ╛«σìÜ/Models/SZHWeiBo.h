//
//  SZHWeiBo.h
//  第二阶段学习day--06--微博
//
//  Created by 石子涵 on 2020/2/29.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SZHWeiBo : NSObject
@property (nonatomic, strong) NSString *text;
@property (nonatomic, strong) NSString *icon;
@property (nonatomic, strong) NSString *picture;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, assign, getter = isVip) BOOL vip;

- (instancetype)initWithDict:(NSDictionary *)dict;
+ (instancetype)weiboWitnDict:(NSDictionary *)dict;

@end

NS_ASSUME_NONNULL_END
