//
//  SZHTableViewController.m
//  第二阶段学习day--06--微博
//
//  Created by 石子涵 on 2020/2/29.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "SZHTableViewController.h"
#import "SZHWeiBo.h"
#import "SZHWeiBoCell.h"

@interface SZHTableViewController ()
@property (nonatomic, strong) NSArray *weibos;
@end

@implementation SZHTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

#pragma mark -懒加载数据
- (NSArray *)weibos{
    if (_weibos == nil) {
        NSString *path = [[NSBundle mainBundle] pathForResource:@"weibos.plist" ofType:nil];
        NSArray *arrayDict = [NSArray arrayWithContentsOfFile:path];
        NSMutableArray *arrayModels = [NSMutableArray new];
        for (NSDictionary *dict in arrayDict) {
            SZHWeiBo *model = [SZHWeiBo weiboWitnDict:dict];
            [arrayModels addObject:model];
        }
        _weibos = arrayModels;
    }
    return _weibos;
}


#pragma mark - Table view 数据源方法

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return self.weibos.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
   //1获取模型数据
    SZHWeiBo *model = self.weibos[indexPath.row];
    //2创建单元格
    NSString *ID = @"weibo_cell";
    SZHWeiBoCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
    }
    //3将数据给单元格
    cell.weibo = model;
    //4返回单元格
    return cell;
}



@end
