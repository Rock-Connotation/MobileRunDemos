//
//  ViewController.m
//  UI基础空间
//
//  Created by 石子涵 on 2020/1/19.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
//@property (nonatomic, weak) UIButton *btn;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //1创建一个按钮
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(50, 100, 100, 100)];
    //给btn设置tag值来方便获得这个控件
    btn.tag = 100;
    //2设置按钮不同状态下的文字以及颜色
    [btn setTitle:@"点我吧。" forState:UIControlStateNormal];
    [btn setTitle:@"摸我干啥？" forState:UIControlStateHighlighted];
    //设置不同状态下的文字颜色
    [btn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor blueColor] forState:UIControlStateHighlighted];
    
    //设置按钮不同状态下的背景图片
    UIImage *image1 = [UIImage imageNamed:@"btn_01"];
    UIImage *image2 = [UIImage imageNamed:@"btn_02"];
    [btn setBackgroundImage:image1 forState:UIControlStateNormal];
    [btn setBackgroundImage:image2 forState:UIControlStateHighlighted];
    
    //将button添加到屏幕上：
    [self.view addSubview:btn];
    //为这个按钮做一个单击事件
    [btn addTarget:self action:@selector(showView) forControlEvents:UIControlEventTouchUpInside];
    
    
    //做几个buttonl来实现对btn的移动旋转缩放和复位。
    //1第一个button实现移动并复位：跳
    UIButton *jump1 = [[UIButton alloc] initWithFrame:CGRectMake(100, 300, 50, 50)];
    [jump1 setTitle:@"up" forState:UIControlStateNormal];
    [jump1 setBackgroundColor:[UIColor blueColor]];
    [jump1 addTarget:self action:@selector(jump4) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:jump1];
    
    UIButton *jump2 = [[UIButton alloc] initWithFrame:CGRectMake(200, 300, 50, 50)];
    [jump2 setTitle:@"down" forState:UIControlStateNormal];
    [jump2 setBackgroundColor:[UIColor blueColor]];
    [jump2 addTarget:self action:@selector(jump3) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:jump2];
}
-(void)showView{
    //设置一个view并将其添加到屏幕上
    UILabel *l1 = [[UILabel alloc] initWithFrame:CGRectMake(100, 200, 100, 100)];
    [l1 setText:@"加油学习啊"];
    l1.backgroundColor = [UIColor redColor];
    [self.view addSubview:l1];

}

-(void)jump4{
    [UIView animateWithDuration:1 animations:^{
        
UIButton *btn2 = (UIButton *)[self.view viewWithTag:100];//利用btn的tag值来获得这个控件
                btn2.transform = CGAffineTransformTranslate(btn2.transform, 0, -50);
//               btn2.transform = CGAffineTransformIdentity;
    }];
}
-(void)jump3{
    [UIView animateWithDuration:1 animations:^{
        
        UIButton *btn3 = (UIButton *)[self.view viewWithTag:100];
        btn3.transform = CGAffineTransformTranslate(btn3.transform, 0, 50);
//        btn2.transform = CGAffineTransformIdentity;
    }];
}


@end
