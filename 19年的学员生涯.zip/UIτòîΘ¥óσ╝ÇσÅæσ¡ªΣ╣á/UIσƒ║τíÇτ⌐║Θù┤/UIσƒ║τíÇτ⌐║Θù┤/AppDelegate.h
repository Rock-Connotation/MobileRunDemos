//
//  AppDelegate.h
//  UI基础空间
//
//  Created by 石子涵 on 2020/1/19.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

