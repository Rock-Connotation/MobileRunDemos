//
//  ViewController.m
//  第二阶段学习day--12--qq界面
//
//  Created by 石子涵 on 2020/3/5.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "ViewController.h"
#import "SZHMessege.h"
#import "SZHMessegeFrame.h"
@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong) NSMutableArray *messageFrames;

@end

@implementation ViewController

#pragma mark -懒加载数据
- (NSMutableArray *)messageFrames{
    if (_messageFrames == nil) {
        NSString *path = [[NSBundle mainBundle] pathForResource:@"messages.plist" ofType:nil];
        NSArray *arrayDict = [NSArray arrayWithContentsOfFile:path];
        NSMutableArray *arrayModels = [NSMutableArray array];
        for (NSDictionary *dict in arrayDict) {
        //创建一个数据模型
        SZHMessege *model = [SZHMessege messegeWithDict:dict];
        //创建一个frame模型
            SZHMessegeFrame *modelFrame = [[SZHMessegeFrame alloc] init];
            modelFrame.messege = model;
            //把frame模型加到arrayModels中
            [arrayModels addObject:modelFrame];
        }
        _messageFrames = arrayModels; 
    }
    return  _messageFrames;
}

#pragma mark -数据源方法
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.messageFrames.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    //1获取模型数据
    SZHMessegeFrame *modelFrame = self.messageFrames[indexPath.row];
    //2创建单元格
    static NSString *ID = @"message_cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:ID];
    }
    //3将模型数据给单元格
//    cell.messageFrames= modelFrame;
    //返回单元格
    return  cell;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
