//
//  AppDelegate.h
//  第二阶段学习day--12--qq界面
//
//  Created by 石子涵 on 2020/3/5.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

