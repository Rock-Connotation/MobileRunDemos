//
//  SZHMessege.m
//  第二阶段学习day--12--qq界面
//
//  Created by 石子涵 on 2020/3/5.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "SZHMessege.h"

@implementation SZHMessege

- (instancetype)initWithDict:(NSDictionary *)dict{
    if(self = [super init]){
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}
+ (instancetype)messegeWithDict:(NSDictionary *)dict{
    return [[self alloc] initWithDict:dict];
}
@end
