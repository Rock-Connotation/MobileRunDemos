//
//  SZHMessegeFrame.h
//  第二阶段学习day--12--qq界面
//
//  Created by 石子涵 on 2020/3/5.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
NS_ASSUME_NONNULL_BEGIN
@class SZHMessege;
@interface SZHMessegeFrame : NSObject

@property (nonatomic, strong) SZHMessege *messege; //引用数据模型
//时间label的frame
@property (nonatomic, assign) CGRect timeFrame;
//t头像的frame
@property (nonatomic, assign) CGRect iconFrame;
//正文的frameframe
@property (nonatomic, assign) CGRect textFrame;
//行高
@property (nonatomic, assign) CGRect rowHeight;



@end

NS_ASSUME_NONNULL_END
