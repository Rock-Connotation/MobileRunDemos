//
//  SZHMessege.h
//  第二阶段学习day--12--qq界面
//
//  Created by 石子涵 on 2020/3/5.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
typedef enum {
    SZHMessegeTypeMe = 0, //表示自己
    SZHMessegeTypeOther = 1//表示其他人
}SZHMessegeType;


@interface SZHMessege : NSObject
@property (nonatomic, copy) NSString *text;
@property (nonatomic, copy) NSString *time;
@property (nonatomic, assign) SZHMessegeType type;


- (instancetype)initWithDict:(NSDictionary *)dict;
+ (instancetype)messegeWithDict:(NSDictionary *)dict;
@end

NS_ASSUME_NONNULL_END
