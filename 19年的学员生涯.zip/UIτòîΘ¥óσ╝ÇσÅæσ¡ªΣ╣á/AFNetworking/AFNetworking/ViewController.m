//
//  ViewController.m
//  AFNetworking
//
//  Created by 石子涵 on 2020/3/8.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "ViewController.h"
#import <AFNetworking.h>
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self requestData];
}
- (void)requestData{
    
    /**
     是AFURLSessionManager的子类，为了便利使用HTTP请求。当一个baseURL提供时，用相对路径构造GET/POST等便利的方法来创建请求。
     */
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
    NSString *token = [user objectForKey:@"token"];
    NSLog(@"2rqwfdsfdsdfadsfasfsaf");
    NSLog(@"%@",token);
    // 请求   TCP/IP                                     http
    AFHTTPRequestSerializer *requestSerializer = [AFHTTPRequestSerializer serializer];
    //添加请求头
    [requestSerializer setValue:token forHTTPHeaderField:@"token"];
    [manager setRequestSerializer:requestSerializer];
    
    // 响应
    AFJSONResponseSerializer *responseSerializer = [AFJSONResponseSerializer serializer];
    [responseSerializer setRemovesKeysWithNullValues:YES];  //去除空值
    responseSerializer.acceptableContentTypes =  [manager.responseSerializer.acceptableContentTypes setByAddingObjectsFromSet:[NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript",@"text/html", @"text/plain",@"application/atom+xml",@"application/xml",@"text/xml",nil]]; //设置接收内容的格式
    [manager setResponseSerializer:responseSerializer];
    
    [manager POST:@"https://cyxbsmobile.sajo.fun/wxapi/mobile-run/getTotalData" parameters:@{} success:^(NSURLSessionDataTask *task, id responseObject) {
        NSLog(@"请求到的数据 = %@", responseObject);
        //hud remove
        NSInteger status = [responseObject[@"status"] integerValue]; //NSNumber
        if (status == 200) { //1.判断请求成功标志   成功，则继续取数据
            NSLog(@"%@",responseObject);
        }else{
            
        }
      
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"=====%@", error); // 404  500
        //MBProgressHUD  服务器异常 请稍后重试
    }];
}

@end
