//
//  SZHApp.m
//  九宫格
//
//  Created by 石子涵 on 2020/1/28.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "SZHApp.h"

@implementation SZHApp
-(instancetype)initWithDic:(NSDictionary *)dic{
    if (self = [super init]) {
        self.name = dic[@"name"];
        self.icon = dic[@"icon"];
    }
    return self;
}
+ (instancetype)appWithDict:(NSDictionary *)dic{
    return [[self alloc] initWithDic:dic];
}

@end
