//
//  ViewController.m
//  九宫格
//
//  Created by 石子涵 on 2020/1/20.
//  Copyright © 2020 石子涵. All rights reserved.
//
 /*
  步骤：1懒加载：建造模型，字典转模型
  */

//shift + option + command + 左/右 折叠/展开所有代码



#import "ViewController.h"
#import "SZHApp.h"
@interface ViewController ()
@property (nonatomic ,strong) NSArray *apps;

@end

@implementation ViewController

-(NSArray *)apps{
  //懒加载
    if (_apps == nil) {
        //1获取date.plist在手机上的路径
        NSString *path = [[NSBundle mainBundle] pathForResource:@"date.plist" ofType:@"nil"];
        //2:根据路径获取数据
        NSArray *arryDic = [NSArray arrayWithContentsOfFile:path];
        //3创建一个可变数组
        NSMutableArray *arryModels = [NSMutableArray array];
        //4遍历字典，把字典转化为一个个模型
        for (NSDictionary *dic in arryDic) {
            //创建一个模型
            SZHApp *model = [[SZHApp alloc] init];
            model.name = dic[@"name"];
            model.icon = dic[@"icon"];
            //将model加到arrModels数组中
            [arryModels addObject:model];
        }
        _apps = arryModels;
    }
    return _apps;
    
    
    
    
}
-(void)setModel:(SZHApp *)model{
    //先赋值
    _model = model;
    //解析数据模型，把模型数据赋值给UIView中的各个子控件
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
   
    
    
    //假设每行应用的个数
    int column = 3;
    //获取大view的宽度
    CGFloat viewWideth = self.view.frame.size.width;
    //设置app的view的高宽
    CGFloat appW = 75;
    CGFloat appH =90;
    CGFloat marginTop = 90; //第一行距离顶部的距离
    CGFloat marginX = (viewWideth - appW * column)/(column + 1); //设置每列的间距
    CGFloat maginY = marginX; //设置每行的间距和每列的间距
    
   
    
    for( int i = 1; i <= 9 ; i++){
        
     SZHApp *appModel = self.apps[i];
        //1创建app的view
        UIView *appview = [[UIView alloc] init];
        //2设置view的属性
        appview.backgroundColor = [UIColor redColor];
        //设置appview的frame
        int colIdx = i%column; //计算m行所在的索引
        int rowIdx = i/column; //计算列所在的索引
        CGFloat appX = marginX + colIdx * (marginX + appW);//设置每一列的x坐标
        CGFloat appY =  marginTop + rowIdx * (marginTop + maginY);//设置每一行的y坐标
        appview.frame = CGRectMake(appX, appY, appW, appH); //设置appview的frame
        //3:将app的view添加到屏幕上
        [self.view addSubview:appview];
        
        //4:向appview中添加三个小控件
        //4.1:添加一个imagine
        UIImageView *imageViewIcon = [[UIImageView alloc] init];
        //设置imagin属性
        //设置imagin的frame
        imageViewIcon.backgroundColor = [UIColor blueColor]; //设置背景颜色

        CGFloat iconW = 45;
        CGFloat iconH = 45;
        CGFloat iconX = (appview.frame.size.width - iconW) * 0.5;
        CGFloat iconY = 0;
        imageViewIcon.frame = CGRectMake(iconX, iconY, iconW, iconH); //设置fram
        [appview addSubview:imageViewIcon];  //将image添加到屏幕上
//        //向其中填充数据
//        imageViewIcon.image = [UIImage imageNamed:appModel.icon];
//
        
        //4.2:添加一个label（标题）
        UILabel *lblName = [[UILabel alloc] init];
        lblName.backgroundColor = [UIColor yellowColor];
        CGFloat nameW = appview.frame.size.width;
        CGFloat nameH = 20;
        CGFloat nameX = 0;
        CGFloat nameY = iconH;
        lblName.frame = CGRectMake(nameX, nameY, nameW, nameH);
        [appview addSubview:lblName];
//        lblName.text = appModel.name;
//        appview.model = appModel;
       
        
        //4.3:添加一个bbutton
        
        
        UIButton *btnDownload = [[UIButton alloc] init];
        btnDownload.backgroundColor = [UIColor greenColor];
        CGFloat btnW = iconW;
        CGFloat btnH = 25;
        CGFloat btnX = iconX;
        CGFloat btnY = nameH + nameY;
        btnDownload.frame = CGRectMake(btnX, btnY, btnW, btnH);
        [appview addSubview:btnDownload];
        
        
    }
    
}


@end
