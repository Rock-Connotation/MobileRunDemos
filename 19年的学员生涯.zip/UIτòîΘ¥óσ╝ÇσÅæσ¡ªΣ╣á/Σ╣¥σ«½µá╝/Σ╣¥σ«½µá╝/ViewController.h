//
//  ViewController.h
//  九宫格
//
//  Created by 石子涵 on 2020/1/20.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SZHApp.h"
@interface ViewController : UIViewController
@property (strong, nonatomic) SZHApp *model;

@end

