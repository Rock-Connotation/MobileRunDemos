//
//  SZHApp.h
//  九宫格
//
//  Created by 石子涵 on 2020/1/28.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SZHApp : NSObject
@property (strong, nonatomic) NSString *name;
@property (strong, nonatomic) NSString *icon;

-(instancetype)initWithDic:(NSDictionary *)dic;
+(instancetype)appWithDict:(NSDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
