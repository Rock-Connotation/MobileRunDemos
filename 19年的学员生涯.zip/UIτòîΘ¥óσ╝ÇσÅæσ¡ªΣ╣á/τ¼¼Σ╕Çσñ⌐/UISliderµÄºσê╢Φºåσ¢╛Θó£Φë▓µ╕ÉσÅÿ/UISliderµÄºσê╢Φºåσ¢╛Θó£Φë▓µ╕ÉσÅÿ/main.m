//
//  main.m
//  UISlider控制视图颜色渐变
//
//  Created by 石子涵 on 2019/11/26.
//  Copyright © 2019 石子涵. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
