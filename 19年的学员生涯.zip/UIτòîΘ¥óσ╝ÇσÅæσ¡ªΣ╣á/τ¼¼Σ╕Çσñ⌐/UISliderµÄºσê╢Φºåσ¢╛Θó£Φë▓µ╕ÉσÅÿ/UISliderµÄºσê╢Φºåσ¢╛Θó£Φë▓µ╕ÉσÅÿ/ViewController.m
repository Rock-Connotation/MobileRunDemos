//
//  ViewController.m
//  UISlider控制视图颜色渐变
//
//  Created by 石子涵 on 2019/11/26.
//  Copyright © 2019 石子涵. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor redColor];//将当前视图的背景色设置为了红色；
    //创建UISlider控件；
    UISlider * slider = [[UISlider alloc] initWithFrame:CGRectMake(20, 100, 280, 400)];
    //设置控件触发方法
    [slider addTarget:self action:@selector(changeBG) forControlEvents:(UIControlEventValueChanged)];
    [self.view addSubview:slider];//将控件添加到屏幕h上
    //changeBG方法代码实现：
    -(void)changeBG:(UISlider *)slider{
        self.view.backgroundColor = [UIColor CGContextSetFillColorWithRed(1 green, 0 blue:0 alpha:1-slider.NSValue ];
    }
                                                                          }


@end
