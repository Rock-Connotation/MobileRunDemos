//
//  ViewController.m
//  UITest
//
//  Created by 石子涵 on 2019/11/24.
//  Copyright © 2019 石子涵. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    UILabel * label = [[UILabel alloc]initWithFrame:(CGRectMake(100, 100, 400, 40))];
    label.numberOfLines = 0;
    label.text = @"风急天高猿啸哀，渚清沙白鸟飞回。";
    label.lineBreakMode =NSLineBreakByTruncatingHead;
    label.textColor = [UIColor redColor];
    [self.view addSubview:label];
    
    UIButton * button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = CGRectMake(200, 200, 100, 30);
    [button setTitle:@"按钮" forState:UIControlStateNormal];
    [self.view addSubview:button];
    button.backgroundColor = [UIColor blueColor];
    UISearchBar *searchBar = [[UISearchBar alloc]initWithFrame:CGRectMake(20, 100, 280, 30)];
    [self.view addSubview:searchBar];
    searchBar.placeholder = @"请输入你想搜索的内容。";
    searchBar.showsBookmarkButton = YES;
    searchBar.showsCancelButton = YES;
    searchBar.showsSearchResultsButton = YES;
    //代理
    searchBar.delegate = self;
//    -(void)UISearchBarIconResultsListButtonClicked:(UISearchBar *)searchBar{
//
//    }
    UISegmentedControl *segmentdControl = [[UISegmentedControl alloc]initWithItems:@[@"one", @"two", @"three",@"four"]];
    segmentdControl.frame = CGRectMake(20,130,280,40);
    [self.view addSubview:segmentdControl];
    segmentdControl.momentary = YES;
    segmentdControl.selectedSegmentIndex = 2;
    
//文本输入交互基础：UITextField
    //创建一个用户登录界面（起始）
    //创建文本输入框（用户名）；
    UITextField * userNameField = [[UITextField alloc] initWithFrame:(CGRectMake(40, 120,  240,40))];
    //创建文本输入框（密码）；
    UITextField * passwordField = [[UITextField alloc] initWithFrame:CGRectMake(40, 200, 240, 40)];
    //设置文本输入框风格： boredStyle属性;
    userNameField.borderStyle = UITextBorderStyleRoundedRect;
    passwordField.borderStyle = UITextBorderStyleRoundedRect;
    //设置输入框默认提示文字 placeholder;
    userNameField.placeholder = @"请输入用户名";
    passwordField.placeholder = @"请输入密码";
    //将其添加到屏幕上（调用？）
    [self.view addSubview:userNameField];
    [self.view addSubview:passwordField];
    //创建并设置登录按钮
    UIButton * btn = [UIButton buttonWithType:UIButtonTypeSystem];
    btn.frame = CGRectMake(110, 260, 100, 30);  //设置a按钮框的位置；
    [btn setTitle:@"立即登录" forState:UIControlStateNormal];
    [self.view addSubview:btn];
    //创建一个用户登录界面（终止）
//为UITextFiel添加挂件
    //设置UITexteField对象的挂件视图属性 <注>：这里需要自己上传图片作为挂件视图
    UIImageView * userImage = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
  //  userNameField.image = [UIImage imageNamed:@"login_user"];//log_user是传入照片的文件名字，下同
    userNameField.leftView = userImage;
    UIImageView * passImage = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
    passImage.image = [UIImage imageNamed:@"login_pwdico"];
    //设置输入框的做挂件视图 ，leftView属性设置输入框左边挂件，rightView属性设置右边挂架；
    passwordField.leftView = passImage;
    userNameField.leftViewMode = UITextFieldViewModeAlways;//leftViewMode属性设置挂件视图的s显示模式
    passwordField.leftViewMode = UITextFieldViewModeAlways;
}

@end
