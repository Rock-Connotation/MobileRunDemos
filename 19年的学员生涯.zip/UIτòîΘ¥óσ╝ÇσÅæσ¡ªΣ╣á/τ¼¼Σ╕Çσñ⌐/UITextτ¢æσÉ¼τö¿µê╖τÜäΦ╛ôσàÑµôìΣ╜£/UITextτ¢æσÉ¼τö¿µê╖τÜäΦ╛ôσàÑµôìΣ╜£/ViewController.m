//
//  ViewController.m
//  UIText监听用户的输入操作
//
//  Created by 石子涵 on 2019/11/26.
//  Copyright © 2019 石子涵. All rights reserved.
//


#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //
//文本输入交互基础：UITextField；
//监听用户的输入操作，需要设置代理
    //创建一个用户登录界面（起始）
    //创建文本输入框（用户名）；
    UITextField * userNameField = [[UITextField alloc] initWithFrame:(CGRectMake(40, 120,  240,40))];
    //创建文本输入框（密码）；
    UITextField * passwordField = [[UITextField alloc] initWithFrame:CGRectMake(40, 200, 240, 40)];
    //设置文本输入框风格： boredStyle属性;
    userNameField.borderStyle = UITextBorderStyleRoundedRect;
    passwordField.borderStyle = UITextBorderStyleRoundedRect;
    //设置输入框默认提示文字 placeholder;
    userNameField.placeholder = @"请输入用户名";
    passwordField.placeholder = @"请输入密码";
    //将其添加到屏幕上（调用？）
    [self.view addSubview:userNameField];
    [self.view addSubview:passwordField];
    //创建并设置登录按钮
    UIButton * btn = [UIButton buttonWithType:UIButtonTypeSystem];
    btn.frame = CGRectMake(110, 260, 100, 30);  //设置a按钮框的位置；
    [btn setTitle:@"立即登录" forState:UIControlStateNormal];
    [self.view addSubview:btn];
    //创建一个用户登录界面（终止）
    
    //设置代理
    userNameField.delegate = self; //自身引用
    [self.view addSubview:btn];
    
}
//实现代理方法如下：
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(nonnull NSString *)string{
    if(string.length >0){
        if([string characterAtIndex:0] <= '9' && [string characterAtIndex:0] >= 0){
            if(textField.text.length <= 10){
                return YES;
            }
        }
        NSLog(@"请输入正确的手机号码");
        return NO;
    }
    return  YES;
}
//收键盘操作
   //点击键盘中的return键进行键盘收起操作的代码
//-（BOOL)textFieldShouldReturn:(UITextField *)textField{
//    [textField resignFirstResponder];
//}
//点击return键时会调用此方法：extFieldShouldReturn，该方法可以注销UITextField控件的第一操作，实现收键盘的逻辑。

////点击屏幕手绘键盘的方式需要重写UIViewController中的一个手势方法，在这个方法中进行UITextField控件注销第一相应操作。
////代码如下：
//     //将textField声明为成员变量
//   @interface ViewController() <UITextFieldDelegate>
//{
//    UITextField * userNameField;
//}
//@end
////重写的touchBegin方法
//-(void)touchesBgan:(NSSet<UITouch * > *)touches withEvent:(UIEvent *) event{
//    
//}
////上面代码即可实现收键盘的逻辑；






@end
