//
//  ViewController.m
//  ViewControllerTest
//
//  Created by 石子涵 on 2020/1/29.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "ViewController.h"
#import "viewControllerTwoViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(100, 100, 100, 100)];
    btn.backgroundColor = [UIColor redColor];
    [self.view addSubview:btn];
    [btn addTarget:self action:@selector(changeController) forControlEvents:UIControlEventTouchUpInside];
}
-(void)changeController{
    viewControllerTwoViewController *viewController = [[viewControllerTwoViewController alloc]init];
    [self presentViewController:viewController animated:YES completion:^{
        NSLog(@"切换完成");
        
    }];
}

@end
