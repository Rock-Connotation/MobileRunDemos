//
//  viewControllerTwoViewController.m
//  ViewControllerTest
//
//  Created by 石子涵 on 2020/1/29.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "viewControllerTwoViewController.h"

@interface viewControllerTwoViewController ()

@end

@implementation viewControllerTwoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor greenColor];
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
