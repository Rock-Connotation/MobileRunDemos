//
//  ViewController.m
//  table学习
//
//  Created by 石子涵 on 2020/1/29.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    // Do any additional setup after loading the view.
//    UITextView *textView = [[UITextView alloc] initWithFrame:CGRectMake(20, 100, 280, 200)];
//    textView.backgroundColor = [UIColor greenColor];
//    textView.font = [UIFont italicSystemFontOfSize:20]; //设置字体大小
//    textView.textColor = [UIColor whiteColor];//设置字体颜色
//    textView.dataDetectorTypes = UIDataDetectorTypeAll; //设置链接类型：所有类型的链接（是枚举）
//    textView.editable = NO;//不可被编辑
//    textView.text = @"phoneNumber:\n159922930154";
//    textView.textAlignment = NSTextAlignmentCenter;//设置文本居中
//    [self.view addSubview:textView];
    //  创建UICollectionView布局策略
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.minimumLineSpacing = 30;
    layout.minimumInteritemSpacing = 10;
    //设置布局方向：(竖直方向)
    layout.scrollDirection = UICollectionViewScrollDirectionVertical;
    //设置其中每个数据载体item的尺寸
    layout.itemSize = CGSizeMake(100,100);
    //创建UICollectionView视图控件
    UICollectionView *collectionView = [[UICollectionView alloc] initWithFrame:self.view.frame collectionViewLayout:layout];
    collectionView.backgroundColor = [UIColor whiteColor];
    //进行数据载体iteam的注册（必须为注册一个作为数据载体类）
    [collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"cellID"];
    //设置代理与数据源
    collectionView.dataSource = self;
    collectionView.delegate = self;
    [self.view addSubview:collectionView];
    
}
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 10;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cellID" forIndexPath:indexPath];
    cell.backgroundColor = [UIColor colorWithRed:arc4random()%255/255.0 green:arc4random()%255/255.0 blue:arc4random()%255/255.0 alpha:arc4random()%255/255.0];
    return cell;
}
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row%2 == 0) {
        return CGSizeMake(50, 50);
    }
    else{
        return CGSizeMake(100, 100);
    }
}
@end
