//
//  SZHGroup.m
//  第二阶段学习day--01
//
//  Created by 石子涵 on 2020/2/24.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "SZHGroup.h"

@implementation SZHGroup
-(instancetype)initWithDict:(NSDictionary *)dict{
    if (self = [super init]) {
        [self setValuesForKeysWithDictionary:dict];
    }
    return  self;
}
+ (instancetype)GroupWithDict:(NSDictionary *)dict{
    return [[self alloc] initWithDict:dict];
}
@end
