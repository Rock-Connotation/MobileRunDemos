//
//  ViewController.m
//  第二阶段学习day--01
//
//  Created by 石子涵 on 2020/2/24.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "ViewController.h"
#import "SZHGroup.h"
@interface ViewController ()<UITableViewDataSource>
@property (nonatomic, strong) NSArray *groups;
@property (weak, nonatomic) IBOutlet UITableView *table;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.table.dataSource = self;
}
#pragma mark -懒加载数据
-(NSArray *)groups{ 
    if (_groups == nil) {
        //懒加载数据
        //找到plist文件的路径
        NSString *path = [[NSBundle mainBundle] pathForResource:@"cars_simple.plist" ofType:nil];
        //获取plist文件
        NSArray *arrayDict = [NSArray arrayWithContentsOfFile:path];
        //字典转模型
        NSMutableArray *arrayModel = [NSMutableArray new];
        //遍历字典数组中的每个字典，把每个字典转成模型，把模型放到arrayModel里面
        for (NSDictionary *dict in arrayDict) {
            //创建模型对象
            SZHGroup *model = [SZHGroup GroupWithDict:dict];
            [arrayModel addObject:model];
        }
        _groups = arrayModel;
        //
    }
    return _groups;
}
#pragma mark -数据源的方法
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.groups.count;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    //根据组索引，获取组对象
    SZHGroup *group = self.groups[section];
    return group.cars.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    //1获取模型数据
    //获取组模型
    SZHGroup *group = self.groups[indexPath.section];
    //获取对应的汽车品牌
    NSString *brand = group.cars[indexPath.row];
    //2创建单元格
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    //3将模型数据f给单元格中的控件
    cell.textLabel.text = brand;
    //返回单元格
    return cell;
}
//设置组标题
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    //获取这一组的组模型数据
    SZHGroup *group = self.groups[section];
    return group.title;
}
//设置组描述
- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section{
    //获取这一组的组模型数据
    SZHGroup *group = self.groups[section];
    return group.desc;
}
@end
