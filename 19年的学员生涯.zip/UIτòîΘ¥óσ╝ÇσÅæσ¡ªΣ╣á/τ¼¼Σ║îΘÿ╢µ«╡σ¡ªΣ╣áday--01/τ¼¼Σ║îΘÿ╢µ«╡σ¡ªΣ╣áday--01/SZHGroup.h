//
//  SZHGroup.h
//  第二阶段学习day--01
//
//  Created by 石子涵 on 2020/2/24.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SZHGroup : NSObject
//组标题
@property(nonatomic, strong) NSString *title;
//组描述
@property(nonatomic, strong) NSString *desc;
//这一组里面的汽车
@property(nonatomic, strong) NSArray *cars;

-(instancetype)initWithDict:(NSDictionary *)dict;
+(instancetype)GroupWithDict:(NSDictionary *)dict; 
@end

NS_ASSUME_NONNULL_END
