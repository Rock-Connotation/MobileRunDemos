//
//  care.h
//  协议
//
//  Created by 石子涵 on 2020/1/19.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol care <NSObject>
-(void)weiNai;
-(void)hongSleep;
-(void)hong;
@end

NS_ASSUME_NONNULL_END
