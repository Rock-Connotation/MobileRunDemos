//
//  Baby.h
//  协议
//
//  Created by 石子涵 on 2020/1/19.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "care.h"
NS_ASSUME_NONNULL_BEGIN

@interface Baby : NSObject
@property (nonatomic, strong) NSString *name;
@property (nonatomic, assign) int age;
@property (nonatomic, strong) id<care> baoMu;

-(void)eat;
-(void)sleep;
-(void)cry;
-(void)wangtSleep;
@end

NS_ASSUME_NONNULL_END
