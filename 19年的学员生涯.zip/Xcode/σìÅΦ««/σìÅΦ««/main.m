//
//  main.m
//  协议
//
//  Created by 石子涵 on 2020/1/19.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Baby.h"
#import "Woman.h"
int main(int argc, const char * argv[]) {
    Baby *b1 = [[Baby alloc] init];
    b1.name = @"宝贝";
    b1.age = 5;
    
    Woman *w1 = [[Woman alloc] init];
    w1.name = @"凤姐";
    b1.baoMu = w1;
    [b1 cry];
    [b1 eat];
    [b1 wangtSleep];
    
    
    return 0;
}
