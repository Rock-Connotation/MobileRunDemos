//
//  Woman.m
//  协议
//
//  Created by 石子涵 on 2020/1/19.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "Woman.h"

@implementation Woman
- (void)hongSleep{
    NSLog(@"宝贝宝贝快睡吧");
}
-(void)weiNai{
    NSLog(@"宝贝宝贝快喝奶吧。");
}
-(void)hong{
    NSLog(@"宝贝不要哭");
}
@end
