//
//  Baby.m
//  协议
//
//  Created by 石子涵 on 2020/1/19.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "Baby.h"

@implementation Baby




-(void)eat{
    NSLog(@"我要喝奶");
    [_baoMu weiNai];
}
-(void)cry{
    NSLog(@"哇啊啊啊啊。。。。。");
    [_baoMu hong];
}
-(void)sleep{
    NSLog(@"zzzzz.....");
}
-(void)wangtSleep{
    NSLog(@"哇啊啊啊...");
    [_baoMu hongSleep];
    [self sleep];
}
@end
