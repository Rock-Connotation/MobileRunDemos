//
//  ViewController.swift
//  红岩第六次课
//
//  Created by 石子涵 on 2019/11/23.
//  Copyright © 2019 石子涵. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func button(_ sender: Any) {
        
    }
    
}

