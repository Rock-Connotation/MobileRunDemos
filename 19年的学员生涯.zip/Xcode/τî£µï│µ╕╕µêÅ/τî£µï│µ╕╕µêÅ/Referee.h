//
//  Referee.h
//  猜拳游戏
//
//  Created by 石子涵 on 2020/1/10.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Player.h"
#import "Robot.h"
NS_ASSUME_NONNULL_BEGIN

@interface Referee : NSObject
//1姓名
@property NSString *name;

-(void)showResultWithPlayer:(Player *)player AndRobot:(Robot *)robot;
@end

NS_ASSUME_NONNULL_END
