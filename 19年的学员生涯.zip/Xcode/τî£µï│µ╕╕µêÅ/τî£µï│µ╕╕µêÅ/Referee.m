//
//  Referee.m
//  猜拳游戏
//
//  Created by 石子涵 on 2020/1/10.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "Referee.h"

@implementation Referee
- (void)showResultWithPlayer:(Player *)player AndRobot:(Robot *)robot{
    //1先拿到玩家和机器人出的拳头
    FistType playerType = player._selectedType;
    FistType robotType = robot._selectedType;
    //2宣布比赛结果,因为剪刀石头布分别代表123，所以用数字来代替枚举 1
    if (playerType - robotType == -1 || playerType - robotType == 2) {
        NSLog(@"胜败乃兵家常事，大侠请重新来过");
        robot.score++;
    }
        else if(playerType == robotType)
        {
            NSLog(@"你们真是心有灵犀呢，居然出的是一样的拳头");
        }
        else{
            NSLog(@"恭喜玩家%@获得胜利", player.name);
        }
}
@end
