//
//  Fist.h
//  猜拳游戏
//
//  Created by 石子涵 on 2020/1/11.
//  Copyright © 2020 石子涵. All rights reserved.
//
typedef enum
{
    FistTypeJianDdao = 1,
    FistTypeShiTou = 2,
    FistTypeBU = 3,
}FistType;
