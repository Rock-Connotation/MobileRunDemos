//
//  Robot.m
//  猜拳游戏
//
//  Created by 石子涵 on 2020/1/10.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "Robot.h"

@implementation Robot

-(void)showFist{
    //1机器人出拳（使用一个显示随机数的函数）
    int robotSelected = arc4random_uniform(3)+1;
    //2显示机器人出的拳头
    NSString *type = [self fistTypeWithNUmber:robotSelected];
    NSLog(@"机器人%@出的拳头是%@", self.name ,type);
    //3将机器人出的拳头保存在机器人的当前属性
    __selectedType = robotSelected;
}

- (NSString *)fistTypeWithNUmber:(int)number{
    switch (number) {
        case 1:
            return @"剪刀";
        case 2:
            return @"石头";
        default:
            return @"布";
    }
}
@end
