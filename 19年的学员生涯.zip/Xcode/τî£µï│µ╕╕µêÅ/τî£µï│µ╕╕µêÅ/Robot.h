//
//  Robot.h
//  猜拳游戏
//
//  Created by 石子涵 on 2020/1/10.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Fist.h"
NS_ASSUME_NONNULL_BEGIN

@interface Robot : NSObject
//1姓名
@property NSString *name;
//2得分
@property int score;
//3出的拳头
@property FistType _selectedType;

-(void)showFist;
-(NSString *)fistTypeWithNUmber:(int)number;
@end

NS_ASSUME_NONNULL_END
