//
//  main.m
//  猜拳游戏
//
//  Created by 石子涵 on 2020/1/10.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Player.h"
#import "Robot.h"
#import "Referee.h"
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Player *p1 = [[Player alloc] init];
        p1.name = @"小明";
        Robot *r1 = [[Robot alloc] init];
        r1.name = @"小黑";
        Referee *f1 = [[Referee alloc] init];
        f1.name = @"黑哨";
        
        while (1) {
             NSLog(@"大家好，我是黑哨，现在由我来为大家宣布比赛结果");
            [p1 showFist];
            [r1 showFist];
            [f1 showResultWithPlayer:p1 AndRobot:r1];
            NSLog(@"爷，您还要继续吗？很刺激的哟。  y/n");
            char ans = 'a';
            rewind(stdin);
            scanf("%c", &ans);
            if(ans != 'y'){
                NSLog(@"爷，欢迎您下次再来玩哦");
                break;
            }
            
        }
        
    }
    return 0;
}
