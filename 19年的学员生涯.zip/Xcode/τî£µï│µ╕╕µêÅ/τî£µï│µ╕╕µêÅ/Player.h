//
//  Player.h
//  猜拳游戏
//
//  Created by 石子涵 on 2020/1/10.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Fist.h"
NS_ASSUME_NONNULL_BEGIN

@interface Player : NSObject
//1.s姓名
@property (nonatomic, copy) NSString *name;

//2 出的拳头(使用枚举)
@property FistType _selectedType;

//3分数
@property int score;

-(void)showFist;
-(NSString *)userSelectTypeWithNumber:(int)numeber;

@end

NS_ASSUME_NONNULL_END
