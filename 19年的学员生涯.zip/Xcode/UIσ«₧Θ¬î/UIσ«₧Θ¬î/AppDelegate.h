//
//  AppDelegate.h
//  UI实验
//
//  Created by 石子涵 on 2019/11/9.
//  Copyright © 2019 石子涵. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

