//
//  ViewController.m
//  计步器demo
//
//  Created by 石子涵 on 2020/9/18.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "ViewController.h"
#import "StepManager.h"
#import "CV2.h"
@interface ViewController ()
{
    NSTimer *_timer;
    UILabel *lable;
//    int second;
}
@property (nonatomic, strong) UIButton *btn;
@property (nonatomic, strong) UIButton *continueBtn;

@property (nonatomic, strong) UILabel *timeLbl;
@property (nonatomic, strong) UIButton *finishBtn; //完成按钮
@property int second;
@property (nonatomic, strong) NSMutableArray *StepsArray;
//@property (nonatomic, strong) NSTimer *timer;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[StepManager sharedManager] startWithStep];                        //计步器开始计步
    lable =[[ UILabel alloc]initWithFrame:CGRectMake(100, 300, 300, 40)];
    [self.view addSubview:lable];
    self.btn = [[UIButton alloc] init];
    [self.btn setTitle:@"停止计步" forState:UIControlStateNormal];
    [self.btn setTitle:@"已经停止计步" forState:UIControlStateHighlighted];
    self.btn.backgroundColor = [UIColor redColor];
    self.btn.frame = CGRectMake(200, 200, 100, 50);
    [self.btn addTarget:self action:@selector(stop) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.btn];
    
    self.continueBtn = [[UIButton alloc] init];
    [self.continueBtn setTitle:@"继续计步" forState:UIControlStateNormal];
    [self.continueBtn setTitle:@"已经继续计步" forState:UIControlStateHighlighted];
    self.continueBtn.backgroundColor = [UIColor greenColor];
    self.continueBtn.frame = CGRectMake(100, 200, 100, 50);
    [self.continueBtn addTarget:self action:@selector(continueStep) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.continueBtn];
    
    self.second = 0;
    self.StepsArray = [NSMutableArray array];
    
    //完成按钮
    self.finishBtn = [[UIButton alloc] init];
    self.finishBtn.backgroundColor = [UIColor redColor];
    [self.finishBtn setTitle:@"完成" forState:UIControlStateNormal];
    self.finishBtn.frame = CGRectMake(200, 400, 100, 100);
    [self.finishBtn addTarget:self action:@selector(changePage) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.finishBtn];
    
    //时间label
    self.timeLbl = [[UILabel alloc] init];
    self.timeLbl.frame = CGRectMake(100, 400, 100, 100);
    [self.view addSubview:self.timeLbl];
    
    //    lable.text = [NSString stringWithFormat:@"我走了 %ld步",(long)[StepManager sharedManager].step];
    _timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(getStepNumber) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:_timer forMode:NSDefaultRunLoopMode];
}

- (void)getStepNumber
{
    lable.text = [NSString stringWithFormat:@"我走了  %ld步",(long)[StepManager sharedManager].step];
    
    self.second++;
    self.timeLbl.text = [NSString stringWithFormat:@"%d",self.second];
    if (self.second %60 == 0) {
        //获取这一分钟的步数
        NSString *stepString = [NSString stringWithFormat:@"%ld",(long)[StepManager sharedManager].step];
        [self.StepsArray addObject:stepString];
        [StepManager sharedManager].step = 0;  //清零
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)stop{
    [[StepManager sharedManager] end];
}

- (void)continueStep{
//    [[StepManager sharedManager] continueSteps];
    [[StepManager sharedManager] startWithStep];
}

//跳转界面
- (void)changePage{
    CV2 *cv = [[CV2 alloc] init];
    cv.StepsAry = self.StepsArray;
    [self.navigationController pushViewController:cv animated:nil];
}

@end
