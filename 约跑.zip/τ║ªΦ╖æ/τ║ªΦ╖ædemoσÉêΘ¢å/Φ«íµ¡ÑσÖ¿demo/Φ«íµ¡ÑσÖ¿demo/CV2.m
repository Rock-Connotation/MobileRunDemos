//
//  CV2.m
//  计步器demo
//
//  Created by 石子涵 on 2020/11/3.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "CV2.h"

@interface CV2 ()

@end

@implementation CV2

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    NSMutableArray *array = [[NSMutableArray alloc] init];
    for (int i = 0; i < 5; i++) {
        int a = 11;
        NSString *string = [NSString stringWithFormat:@"%d",a * (i+1)];
        [array addObject:string];
    }
    for (int i = 0; i < self.StepsAry.count; i++) {
        UILabel *label = [[UILabel alloc] init];
        label.text = self.StepsAry[i];
        label.frame = CGRectMake(50 + 20 * (i + 1), 300 + 20 * (i/5 + 1), 50, 30);
        [self.view addSubview:label];
    }
//    for (int i = 0; i < array.count; i++) {
//        UILabel *label = [[UILabel alloc] init];
//        label.text = array[i];
//        label.frame = CGRectMake(50 + 50 * (i + 1), 300 , 50, 30);
//        [self.view addSubview:label];
    }


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
