//
//  ViewController.m
//  内存测试
//
//  Created by 石子涵 on 2020/9/4.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "ViewController.h"
#import "ViewController2.h"
@interface ViewController ()
@property (nonatomic, strong) UIButton *btn;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    UIButton *btn = [[UIButton alloc] init];
    btn.frame = CGRectMake(100, 100, 100, 100);
    btn.backgroundColor = [UIColor redColor];
    self.btn = btn;
    [self.btn addTarget:self action:@selector(push) forControlEvents:UIControlEventTouchUpInside];
     [self.view addSubview:btn];
}
- (void)push{
    ViewController2 *cv = [[ViewController2 alloc] init];
    [self.navigationController pushViewController:cv animated:YES];
//    [self presentViewController:cv animated:YES completion:nil];
    
}
//- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
//     ViewController2 *cv = [[ViewController2 alloc] init];
//        [self.navigationController pushViewController:cv animated:YES];
//}
- (void)dealloc{
    NSLog(@"123");
}

@end
