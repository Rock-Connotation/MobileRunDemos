//
//  ViewController.m
//  健康计步+画图
//
//  Created by 石子涵 on 2020/11/9.
//

#import "ViewController.h"
#import <HealthKit/HealthKit.h>
@interface ViewController ()

@property (nonatomic, strong) HKHealthStore *healthStore;

/// 收集步频数值
@property (nonatomic, strong) NSMutableArray *stepsAry;

/// 展示分钟步频数值
@property (nonatomic, strong) UILabel *stepLabel;

/// 用于显示时间的label
@property (nonatomic, strong) UILabel *timeLbl;

/// 用于计算秒数的计时器
@property (nonatomic ,strong) NSTimer *timer;

/// 秒数
@property int seconds;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //显示步频的label
    self.stepLabel = [[UILabel alloc] init];
    self.stepLabel.frame = CGRectMake(100, 200, 200, 200);
//    self.stepLabel.textColor = [UIColor whiteColor];
//    self.stepLabel.backgroundColor = [UIColor redColor];
    [self.view addSubview:self.stepLabel];
    self.stepLabel.text = @"0";
    
    //显示时间的label
    self.timeLbl = [[UILabel alloc] init];
    self.timeLbl.frame = CGRectMake(100, 50, 200, 100);
    [self.view addSubview:self.timeLbl];
    
    self.stepsAry = [NSMutableArray array];
    
    self.seconds = 0;
    
    self.timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(continueRun) userInfo:nil repeats:YES];
    // Do any additional setup after loading the view.
}

/// 计时器方法，每秒执行一次
- (void)continueRun{
    self.seconds++; //秒数加1
    self.timeLbl.text = [NSString stringWithFormat:@"%d",self.seconds];
    //当进行的时间每到一分钟（是60的倍数）的时候执行查询步数的操作
    if (self.seconds%30 == 0) { //为测试，改为30秒查询一次
        [self healthManagerConfig];
    }
}

/// 调取健康数据
- (void)healthManagerConfig{
   
}

@end
