//
//  SZHHealthManager.h
//  健康计步+画图
//
//  Created by 石子涵 on 2020/11/9.
//

#import <Foundation/Foundation.h>
#import <HealthKit/HealthKit.h>
NS_ASSUME_NONNULL_BEGIN

/// 用来读取健康数据的单类
@interface SZHHealthManager : NSObject
@property (nonatomic, strong) HKHealthStore *healthStore;

/// 单例方法
+ (id)shareInstance;

/// 权限验证
/// @param completion 代码块，是否验证成功
- (void)authorizeHealthKit:(void(^)(BOOL success, NSError *error))completion;


/// 跑步界面获取步数
/// @param completion :value :传出这一分钟步数; error：错误信息
- (void)getStepsRunningCompletion:(void(^)(int value, NSError *error))completion;

@end

NS_ASSUME_NONNULL_END
