//
//  SZHHealthManager.m
//  健康计步+画图
//
//  Created by 石子涵 on 2020/11/9.
//
#import <UIKit/UIDevice.h>
#import "SZHHealthManager.h"

#define HKVersion [[[UIDevice currentDevice] systemVersion] doubleValue]  //取系统版本号
#define CustomHealthErrorDomain @"com.sdqt.healthError"
@implementation SZHHealthManager

/// 单例，程序启动后全局通用
+ (id)shareInstance{
    static id manager; //只开辟一次空间，存储在静态空间
    static dispatch_once_t onecToken;
    dispatch_once(&onecToken, ^{
        manager = [[[self  class]alloc] init];
    });
    return manager;
}

/// 检查是否支持获取健康数据
/// @param completion <#completion description#>
- (void)authorizeHealthKit:(void (^)(BOOL, NSError * _Nonnull))completion{
    if (HKVersion >= 8.0 ) {
        if (![HKHealthStore isHealthDataAvailable]) {
            NSLog(@"该设备不支持读取健康数据");
        }else{
            //只需初始化一次
            if (self.healthStore == nil) {
                self.healthStore = [[HKHealthStore alloc] init];
            }
            //                //组装需要读写的数据类型
            ////               NSSet *writeDataTypes = [self dataTypesToWrite];
            //            NSSet *readDataTypes = [self dataTypesRead];
            //
            //            //注册需要读写的数据类型，也可以在"设置 - 健康"中重新修改
            //            //ShareTypes  写的内容
            //            //readTypes   读的内容
            
            //获取需要读取的权限，此处仅只需要获取步数
            HKObjectType *stepCount = [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierStepCount];
            NSSet *healthSet = [NSSet setWithObject:stepCount];
            
            //从健康中获取数据
            [self.healthStore requestAuthorizationToShareTypes:nil readTypes:healthSet completion:^(BOOL success, NSError * _Nullable error) {
                if (completion != nil) {
                    NSLog(@"error->%@",error.localizedDescription);
                    completion(success, error);
                }
            }];
        }
    }
}

- (void)getStepsRunningCompletion:(void (^)(int value, NSError * _Nonnull))completion{
    //1.确定类型 HKQuantityTypeIdentifierStepCount
//    HKQuantityType *stepType = [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierStepCount];
    HKQuantityType *stepType = [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierStepCount];
    
    //2确定检索 NSSortDescriptors用来告诉healthStore怎么样将结果排序。
    NSSortDescriptor *start = [NSSortDescriptor sortDescriptorWithKey:HKSampleSortIdentifierStartDate ascending:NO];
    NSSortDescriptor *end = [NSSortDescriptor sortDescriptorWithKey:HKSampleSortIdentifierEndDate ascending:NO];
    
    //3.确定样本的采取时间 此处的检索时间是一根中前后
    NSDate *now = [NSDate date];
    NSDate *laterOneMinut = [NSDate dateWithTimeIntervalSinceNow:-30];
    NSPredicate *predicate2 = [HKQuery predicateForSamplesWithStartDate:laterOneMinut endDate:now options:HKQueryOptionNone];
    
    //4.检索数据
    HKSampleQuery *query = [[HKSampleQuery alloc] initWithSampleType:stepType predicate:predicate2 limit:HKObjectQueryNoLimit sortDescriptors:@[start,end] resultsHandler:^(HKSampleQuery * _Nonnull query, NSArray<__kindof HKSample *> * _Nullable results, NSError * _Nullable error) {
        if (error) {
            completion(0,error);
        }else{
            //设置一个int型变量来作为步数统计
            int allStepCount = 0;
            for (int i = 0; i < results.count; i++) {
                //把结果转换为字符串类型
                HKQuantitySample *result = results[i];
                HKQuantity *quantity = result.quantity;
                NSMutableString *stepCount = (NSMutableString *)quantity;
                 NSString *stepStr =[ NSString stringWithFormat:@"%@",stepCount];
                //获取51 count此类字符串前面的数字
                 NSString *str = [stepStr componentsSeparatedByString:@" "][0];
                int stepNum = [str intValue];
                 NSLog(@"%d",stepNum);
                 //把一天中所有时间段中的步数加到一起
                allStepCount = allStepCount + stepNum;
            }
            NSLog(@"今天的总步数＝＝＝＝%d",allStepCount);
        }
    }];
    //5.执行检索
    [self.healthStore executeQuery:query];
    
}
@end
