//
//  SceneDelegate.h
//  健康计步+画图
//
//  Created by 石子涵 on 2020/11/9.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

