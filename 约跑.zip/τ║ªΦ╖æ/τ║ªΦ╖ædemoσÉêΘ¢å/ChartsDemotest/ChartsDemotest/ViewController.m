//
//  ViewController.m
//  ChartsDemotest
//
//  Created by 石子涵 on 2020/8/5.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "ViewController.h"
#import "ZHLineChartView.h"

@interface ViewController ()
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) ZHLineChartView *lineView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
     [self.lineView drawLineChart];
    // Do any additional setup after loading the view.
}
- (UIScrollView *)scrollView
{
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
        _scrollView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.1];
        _scrollView.contentSize = CGSizeMake(CGRectGetWidth(self.view.frame), 1300);
        [self.view addSubview:_scrollView];
    }
    return _scrollView;
}

- (ZHLineChartView *)lineView
{
    if (!_lineView) {
        _lineView = [[ZHLineChartView alloc] initWithFrame:CGRectMake(0, 10, CGRectGetWidth(self.view.frame), 200)];
        _lineView.lineWidth = 1;
        _lineView.lineColor = [UIColor colorWithRed:56/255.0 green:190/255.0 blue:216/255.0 alpha:0.8];
        _lineView.max = @250;
        _lineView.min = @0;
        _lineView.horizontalDataArr = @[@"0", @"5", @"10", @"15", @"20", @"25"];
        
        _lineView.lineDataAry = @[@100, @150, @182, @160, @163, @175];
        _lineView.splitCount = 5;
        _lineView.toCenter = NO;
        _lineView.edge = UIEdgeInsetsMake(25, 15, 50, 25);
        [self.scrollView addSubview:_lineView];
        _lineView.showKeyPoints = NO;
        _lineView.showLineData = NO;
        _lineView.showColorGradient = YES;
        _lineView.angle = 0;
//        _lineView.colorArr = [NSArray arrayWithObjects:(id)[[UIColor colorWithRed:56/255.0 green:190/255.0 blue:216/255.0 alpha:0.8] CGColor],(id)[[UIColor colorWithRed:207/255.0 green:191/255.0 blue:0/255.0 alpha:0.1] CGColor], nil];
    }
    return _lineView;
}

@end
