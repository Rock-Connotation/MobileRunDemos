//
//  ViewController.m
//  约跑网络连接测试
//
//  Created by 石子涵 on 2020/9/27.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "ViewController.h"
#import <AFNetworking.h>
#import "NSString+NumberValue.h"
#define HandUpDate @"https://cyxbsmobile.redrock.team/wxapi/mobile-run/sportRecord"
@interface ViewController ()

@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    NSMutableDictionary *paramDic = [NSMutableDictionary new];
    NSMutableArray *stepAry = [NSMutableArray new]; //步频数组
    NSMutableArray *array1 = [NSMutableArray new];  //位置数组
    
    NSArray *originStepsAry = @[@"66",@"77",@"88",@"99",@"101"];
    for (int i = 0; i < originStepsAry.count; i++) {
        NSString *step = originStepsAry[i];
        NSString *stepIndex = [NSString stringWithFormat:@"%d", i+1];
        NSNumber *n1 =@([stepIndex intValue]);
        NSNumber *n2 = @([step intValue]);
        NSMutableArray *array = [NSMutableArray array];
        
        [array addObject:n1];
        [array insertObject:n2 atIndex:1];
        [stepAry addObject:array];
    }
    
    NSLog(@"步频数组------%@",stepAry);
    
    
    NSString *string1 = @"37.324746";
    NSString *string2 = @"-122.021605";
    NSNumber *numberq1 = string1.doubleNumber;
    NSNumber *number2 = @([string2 doubleValue]);
    NSMutableArray *pathary = [NSMutableArray new];
    [pathary addObject:numberq1];
    [pathary addObject:number2];
    NSMutableArray *pathARY = [NSMutableArray new];
    [pathARY addObject:pathary];
    
    
    //上传参数
    [paramDic setValue:@31 forKey:@"temperature"];
    [paramDic setValue:0 forKey:@"weather"];
    [paramDic setValue:pathARY forKey:@"path"];
    [paramDic setObject:stepAry forKey:@"stepFrequency"];
    
    //请求头·
    NSString *string = @"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJTdHVudW0iOiIyMDE5MjE0MTEwIiwiZXhwIjoxNjAxNDc0NTI4LCJpc3MiOiJtb2JpbGVSdW5Zb3UifQ.evNjk536TnJA1vIP2F9SGgEj2pHO3L6B5f7HWBL6vFc";
    NSMutableDictionary *headDic = [NSMutableDictionary new];
    [headDic setValue:string forKey:@"token"];
    [headDic setValue:@"application/json" forKey:@"Content-Type"];
    AFHTTPSessionManager  *manager = [AFHTTPSessionManager manager];
    //序列化
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    AFJSONResponseSerializer *responseSerializer = [AFJSONResponseSerializer serializer];
    [responseSerializer setRemovesKeysWithNullValues:YES];  //去除空值
    responseSerializer.acceptableContentTypes =  [manager.responseSerializer.acceptableContentTypes setByAddingObjectsFromSet:[NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript",@"text/html", @"text/plain",@"application/atom+xml",@"application/xml",nil]]; //设置接收内容的格式
    [manager setResponseSerializer:responseSerializer];
    
    __block NSDictionary *dataDict = [[NSDictionary alloc] init];
    [manager POST:HandUpDate parameters:paramDic headers:headDic progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
//        NSLog(@"-----------上传数据成功，得到的结果为%@",responseObject);
//        NSLog(@"---------···上传的数据为%@",paramDic);
//        NSLog(@"上传步频数据成功-----%@",[paramDic objectForKey:@"stepFrequency"]);
        NSLog(@"返回结果是--%@",responseObject);
//        NSLog(@"状态码是---%@",responseObject[@"status"]);
//        NSLog(@"info是---%@",responseObject[@"info"]);
        dataDict = responseObject;
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"%@",error);

       NSData *data = error.userInfo[@"com.alamofire.serialization.response.error.data"] ;
       NSString *errorStr = [[ NSString alloc ] initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"%@",errorStr);

    }];
   
    //延迟一秒
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSLog(@"拿出来的数据是是-----%@",dataDict);
    });
   
}


@end
