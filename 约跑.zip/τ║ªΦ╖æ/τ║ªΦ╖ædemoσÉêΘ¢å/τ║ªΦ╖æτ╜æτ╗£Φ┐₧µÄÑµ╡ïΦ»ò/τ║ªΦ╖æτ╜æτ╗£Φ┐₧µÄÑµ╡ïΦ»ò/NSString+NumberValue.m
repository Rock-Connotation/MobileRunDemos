//
//  NSString+NumberValue.m
//  AFNetworking
//
//  Created by 石子涵 on 2020/9/29.
//

#import "NSString+NumberValue.h"

@implementation NSString (NumberValue)
- (NSNumber *)doubleNumber{
    return @(self.doubleValue);
}
@end
