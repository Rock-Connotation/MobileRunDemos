//
//  ViewController.m
//  约跑首页滑动动画demo
//
//  Created by 石子涵 on 2020/9/29.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "ViewController.h"
#import "MainView.h"
@interface ViewController ()
@property (nonatomic, strong) MainView *mainView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.mainView = [[MainView alloc] init];
    self.mainView.frame = self.view.frame;
    [self.mainView setSomething];
    [self.view addSubview:self.mainView];
    // Do any additional setup after loading the view.
}


@end
