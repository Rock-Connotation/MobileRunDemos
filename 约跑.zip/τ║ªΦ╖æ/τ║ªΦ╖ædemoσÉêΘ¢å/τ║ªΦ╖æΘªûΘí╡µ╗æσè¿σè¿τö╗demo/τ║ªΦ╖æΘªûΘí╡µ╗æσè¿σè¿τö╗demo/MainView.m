//
//  MainView.m
//  约跑首页滑动动画demo
//
//  Created by 石子涵 on 2020/9/29.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "MainView.h"
@interface MainView()<UIGestureRecognizerDelegate>
@property CGPoint containerOrigin;

@end
@implementation MainView
- (void)setSomething{
    //topView
    self.topView = [[UIView alloc] init];
    self.topView.frame = self.frame;
    [self addSubview:self.topView];
    self.topView.backgroundColor = [UIColor whiteColor];
    self.topView.alpha = 0.6;
    
    //底部的button
    self.bottomView = [[UIView alloc] init];
    self.bottomView.backgroundColor = [UIColor yellowColor];
    self.bottomView.frame = CGRectMake(0, screenHeigth * 0.537, screenWidth, screenHeigth - screenHeigth * 0.537);
    [self addSubview:self.bottomView];
    
    //拖动的label
    self.dragLabel = [[UILabel alloc] init];
    self.dragLabel.backgroundColor = [UIColor redColor];
    self.dragLabel.frame = CGRectMake(0, 0, screenWidth, 26);
    [self.bottomView addSubview:self.dragLabel];
    
    //显示数字的label
    self.numberLabel = [[UILabel alloc] init];
    self.numberLabel.text = @"4.26";
    self.numberLabel.font = [UIFont systemFontOfSize:82];
    self.numberLabel.textAlignment = NSTextAlignmentCenter;
    self.numberLabel.frame = CGRectMake(0, screenHeigth * 0.2669, screenWidth, 100);
    [self addSubview:self.numberLabel];
    
    //显示公里的label
    self.mileLabel = [[UILabel alloc] init];
    self.mileLabel.text = @"公里";
    self.mileLabel.textAlignment = NSTextAlignmentCenter;
    self.mileLabel.font = [UIFont systemFontOfSize:15];
    self.mileLabel.frame = CGRectMake(screenWidth * 0.4427, screenHeigth * 0.2669 + 100, 44, 30);
    [self addSubview:self.mileLabel];
    
//右上角显示数字的label
    self.numberLabel2 = [[UILabel alloc] init];
    self.numberLabel2.text = @"4.26";
    self.numberLabel2.font = [UIFont systemFontOfSize: 30];
    self.numberLabel2.frame = CGRectMake(screenWidth * 0.64, screenHeigth * 0.0497, 84, 53);
    self.numberLabel2.alpha = 0;
    [self addSubview:self.numberLabel2];
    
    //添加手势
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(dragAction:)];
    [self.bottomView addGestureRecognizer:pan];
    self.bottomView.userInteractionEnabled = YES;
}
- (void)dragAction:(UIPanGestureRecognizer *)recognizer{
    CGPoint point = [recognizer translationInView:self.bottomView];
    if (recognizer.state == UIGestureRecognizerStateBegan) {
           self.containerOrigin = recognizer.view.frame.origin;
       }
    // 2.手势移动过程中: 在边界处做判断,其他位置
           if (recognizer.state == UIGestureRecognizerStateChanged) {
               CGRect frame = recognizer.view.frame;
               frame.origin.y = self.containerOrigin.y + point.y;
               if (frame.origin.y < screenHeigth * 0.6) { // 上边界
                   frame.origin.y = screenHeigth * 0.6;
               }
               
               if (frame.origin.y > screenHeigth * 0.8) { // 下边界
                   frame.origin.y = screenHeigth * 0.8;
               }
              
               recognizer.view.frame = frame;
           }
     // 3.手势结束后:有向上趋势,视图直接滑动至上边界, 向下趋势,视图直接滑动至到下边界
     if (recognizer.state == UIGestureRecognizerStateEnded){
          if ([recognizer velocityInView:self.bottomView].y < 0) {
              NSLog(@"向上");
              [UIView animateWithDuration:0.20 animations:^{
                  CGRect frame = recognizer.view.frame;
                  frame.origin.y = screenHeigth * 0.6;
                  recognizer.view.frame = frame;
                  self.numberLabel2.alpha = 0;
                  self.topView.alpha = 0.05;
              }];
              [UIView animateWithDuration:0.5 delay:0.5 usingSpringWithDamping:0.5 initialSpringVelocity:0 options:nil animations:^{
                  self.numberLabel.alpha = 1;
              } completion:nil];
              
              
          }else {
              NSLog(@"向下");
              [UIView animateWithDuration:0.20 animations:^{
                  CGRect frame = recognizer.view.frame;
                  frame.origin.y = screenHeigth * 0.8;
                  recognizer.view.frame = frame;
                   self.numberLabel.alpha = 0;
                   self.topView.alpha = 0;
              }];
 
              [UIView animateWithDuration:0.5 delay:0.5 usingSpringWithDamping:0.5 initialSpringVelocity:0 options:nil animations:^{
                  self.numberLabel2.alpha = 1;
              } completion:nil];
             
          }
     }
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
