//
//  MainView.h
//  约跑首页滑动动画demo
//
//  Created by 石子涵 on 2020/9/29.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
#define screenHeigth  [UIScreen mainScreen].bounds.size.height
#define screenWidth   [UIScreen mainScreen].bounds.size.width
@interface MainView : UIView
@property (nonatomic, strong)UIView *bottomView;
@property (nonatomic, strong)UIView *topView;
@property (nonatomic, strong)UILabel *numberLabel;
@property (nonatomic, strong)UILabel *mileLabel;
@property (nonatomic, strong)UILabel *dragLabel;

//右上角的公里和公里数
@property (nonatomic, strong)UILabel *numberLabel2;
@property (nonatomic, strong)UILabel *mileLabel2;

- (void)setSomething;
@end

NS_ASSUME_NONNULL_END
