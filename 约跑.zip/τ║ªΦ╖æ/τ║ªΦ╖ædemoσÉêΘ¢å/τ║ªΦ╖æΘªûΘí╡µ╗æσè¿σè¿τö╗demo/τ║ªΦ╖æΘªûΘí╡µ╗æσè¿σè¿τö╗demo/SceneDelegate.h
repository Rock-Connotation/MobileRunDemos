//
//  SceneDelegate.h
//  约跑首页滑动动画demo
//
//  Created by 石子涵 on 2020/9/29.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

