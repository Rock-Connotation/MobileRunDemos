//
//  ViewController.h
//  mapTestDemo
//
//  Created by 石子涵 on 2020/8/3.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AFNetworking.h>
@interface ViewController : UIViewController

@property (nonatomic, assign) double distance;
@property (nonatomic, strong) NSMutableArray *mutableLocationArry;
@property (nonatomic, strong) NSArray *locationArray;
@property (nonatomic, strong) NSMutableArray *muteableDrawLineAry;
@property (nonatomic, strong) NSArray *drawLineAry;

@end

