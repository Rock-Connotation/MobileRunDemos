//
//  ViewController.m
//  mapTestDemo
//
//  Created by 石子涵 on 2020/8/3.
//  Copyright © 2020 石子涵. All rights reserved.
//
#import <MAMapKit/MAMapKit.h>
#import <AMapFoundationKit/AMapFoundationKit.h>
#import <MapKit/MapKit.h>
#import <AMapLocationKit/AMapLocationKit.h>
#import <Masonry.h>
#import <AFNetworking.h>

#import "ViewController.h"
#import "RunLocationModel.h"
#import "SZHCV2.h"
@interface ViewController ()<AMapLocationManagerDelegate,MAMapViewDelegate>

@property (nonatomic, strong) MAMapView *mapView;
@property (nonatomic, strong) AMapLocationManager *locationManager;
@property (nonatomic, strong) UILabel *distanceLabel; //显示距离的label


@property (nonatomic, strong) RunLocationModel *RunlocationModel;

@property (nonatomic, strong) NSTimer *reloadTimer;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    [AMapServices sharedServices].enableHTTPS = YES;
    self.mutableLocationArry  = [[NSMutableArray alloc] init];
    self.muteableDrawLineAry = [[NSMutableArray alloc] init];
    //初始化地图
    [self initMapView];

    [self initLabelAndBtn]; //初始化地图和label
    //初始化位置管理者
    [self initLocationManager];


    self.distanceLabel.text = [NSString stringWithFormat:@"%0.02f",self.distance];
    
}

//请求下载自定义地图



//label和butto
- (void)initLabelAndBtn{
    self.distanceLabel = [[UILabel alloc] init];
    [self.mapView addSubview:_distanceLabel];
    [self.distanceLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(80, 50));
        make.top.equalTo(self.view).offset(200);
        make.right.equalTo(self.view).offset(-40);
    }];
    self.distanceLabel.textAlignment = NSTextAlignmentCenter;
    self.distanceLabel.font = [UIFont systemFontOfSize:28];
    self.distance = 0.00;
    self.distanceLabel.text = [NSString stringWithFormat:@"%0.02f",self.distance ];
    
    
    UIButton *endbutton = [[UIButton alloc] init];
    [endbutton setTitle:@"完成" forState:UIControlStateNormal];
    [endbutton setTintColor:[UIColor whiteColor]];
    endbutton.backgroundColor = [UIColor blackColor];
    [self.mapView addSubview:endbutton];
    [endbutton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(80, 50));
        make.centerX.equalTo(self.view);
        make.bottom.equalTo(self.view).offset(-120);
    }];
    [endbutton addTarget:self action:@selector(jump) forControlEvents:UIControlEventTouchUpInside];
    
}
#pragma mark- 加载地图和位置管理者
 //地图
//- (void)initMapView{
//    self.mapView = [[MAMapView alloc] initWithFrame:self.view.bounds];
//    
//     self.mapView.delegate = self;
//        //  不支持旋转
//        self.mapView.rotateEnabled = NO;
//        //倾斜收拾
//        self.mapView.rotateCameraEnabled = NO;
//    //    表示不显示比例尺
//        self.mapView.showsScale= NO;
//        ///如果您需要进入地图就显示定位小蓝点，则需要下面两行代码
//        self.mapView.showsUserLocation = YES;
//        self.mapView.userTrackingMode = MAUserTrackingModeFollow;
//      
//        //  自定义地图样式
//        NSString *path =   [[NSBundle mainBundle] pathForResource:@"style" ofType:@"data"];
//        NSData *data = [NSData dataWithContentsOfFile:path];
////        NSString *extrapath = [[NSBundle mainBundle] pathForResource:@"style_extra" ofType:@"data"];
////        NSData *extradata = [NSData dataWithContentsOfFile:extrapath];
//        MAMapCustomStyleOptions *options = [[MAMapCustomStyleOptions alloc] init];
//    //    options.styleId = @"74dcfe3a9ed7a2b181e7af11aea1ea9d";
//        options.styleData = data;
////        options.styleExtraData = extradata;
//        [self.mapView setCustomMapStyleOptions:options];
//        [self.mapView setCustomMapStyleEnabled:YES];
//     [self.view addSubview:self.mapView];
//}
- (void)initMapView{
    if (!self.mapView) {
        MAMapView *mapview = [[MAMapView alloc] initWithFrame:self.view.bounds];
        self.mapView = mapview;
//        self.mapView.mapType = MAMapTypeStandard; //设置地图类型
        self.mapView.zoomLevel = 18;
        self.mapView.showsUserLocation = YES;
        self.mapView.pausesLocationUpdatesAutomatically = NO;
        self.mapView.showsCompass = NO;
        self.mapView.showsScale = NO;
        self.mapView.userInteractionEnabled = YES;
        self.mapView.delegate = self; //设置地图代理
        //自定义用户位置小蓝带你
        MAUserLocationRepresentation *r = [[MAUserLocationRepresentation alloc] init];
        r.showsAccuracyRing = NO; //不显示精度圈
        [self.mapView updateUserLocationRepresentation:r];
        [self.view addSubview:self.mapView];
        NSLog(@"地图已经加载");
    }
}
 //位置管理者
- (void)initLocationManager{
    if (!self.locationManager) {
        self.locationManager = [[AMapLocationManager alloc] init];
        self.locationManager.delegate = self;
        self.locationManager.distanceFilter = 5; //最小距离更新位置
        [self.locationManager startUpdatingLocation]; //开始位置更新
    }
}
#pragma mark- 位置管理者的代理方法
//接收位置更新
- (void)amapLocationManager:(AMapLocationManager *)manager didUpdateLocation:(CLLocation *)location reGeocode:(AMapLocationReGeocode *)reGeocode{
    if (self.locationArray.count == 0){
        RunLocationModel *firstModel = [[RunLocationModel alloc] init];
        firstModel.location = location.coordinate;
        
        
        //向位置数组添加元素
        [self.mutableLocationArry addObject:firstModel];
        self.locationArray = self.mutableLocationArry;
        //向绘制折线的数组添加元素
        [self.muteableDrawLineAry addObject:firstModel];
        self.drawLineAry = self.muteableDrawLineAry;
        
        NSLog(@"第一次定位，数组内数量为%lu",(unsigned long)self.locationArray.count);
    }else if (self.locationArray.count != 0){
        RunLocationModel *lastLocation = self.locationArray.lastObject;
        self.RunlocationModel = [[RunLocationModel alloc] init];
        self.RunlocationModel.location = location.coordinate;
        
        //计算距离
        MAMapPoint lastPoint =  MAMapPointForCoordinate(lastLocation.location);
        MAMapPoint currentPoint = MAMapPointForCoordinate(self.RunlocationModel.location);
        CLLocationDistance newdistance = MAMetersBetweenMapPoints(lastPoint, currentPoint);
        
        self.distance = self.distance + newdistance/1000;
        NSLog(@"已经移动的距离为%0.02f",self.distance);
        self.distanceLabel.text = [NSString stringWithFormat:@"%0.02f",self.distance];
        
        //如果两个定位点的距离超过五米，就绘制轨迹,并将该点加入绘制折线的数组
        if (newdistance >= 5) {
            CLLocationCoordinate2D linPoints[2];
            linPoints[0] = lastLocation.location;
            linPoints[1] = self.RunlocationModel.location;
            //调用addOverlay方法后进入 renderForOverlay方法，完成对轨迹的绘制
            MAPolyline *lineSection = [MAPolyline polylineWithCoordinates:linPoints count:2];
            [self.mapView addOverlay:lineSection];
            
            //向绘制轨迹的位置数组添加元素
            [self.muteableDrawLineAry addObject:self.RunlocationModel];
            self.drawLineAry = self.muteableDrawLineAry;
            NSLog(@"绘制折线数组内元素为%lu",(unsigned long)self.drawLineAry.count);
        }
        
        [self.mutableLocationArry addObject:self.RunlocationModel];
        self.locationArray = self.mutableLocationArry;
        NSLog(@"非第一次定位，位置数组数量为%lu",(unsigned long)self.locationArray.count);
    }
}

#pragma mark- 轨迹线的设置
- (MAOverlayRenderer *)mapView:(MAMapView *)mapView rendererForOverlay:(id<MAOverlay>)overlay{
    if ([overlay isKindOfClass:[MAPolyline class]]){
         MAPolylineRenderer *polyLineRender = [[MAPolylineRenderer alloc] initWithPolyline:overlay];
        polyLineRender.lineWidth = 8;
        polyLineRender.strokeColor = [UIColor colorWithRed:123/255.0 green:183/255.0 blue:196/255.0 alpha:1.0]; //折线颜色
    }
    return nil;
}

#pragma mark-使用后台定位服务需要用到的代理方法
- (void)mapViewRequireLocationAuth:(CLLocationManager *)locationManager{
    [locationManager requestAlwaysAuthorization];
}

- (void)amapLocationManager:(AMapLocationManager *)manager doRequireLocationAuth:(CLLocationManager *)locationManager{
    [locationManager requestAlwaysAuthorization];
}

//按钮方法，跳转到下一个界面
- (void)jump{
    SZHCV2 *cv = [[SZHCV2 alloc] init];
    cv.drawLineAry = self.drawLineAry;
    cv.locationAry = self.locationArray;
    [self.locationManager stopUpdatingLocation];
    [self.navigationController pushViewController:cv animated:YES];
}
@end
