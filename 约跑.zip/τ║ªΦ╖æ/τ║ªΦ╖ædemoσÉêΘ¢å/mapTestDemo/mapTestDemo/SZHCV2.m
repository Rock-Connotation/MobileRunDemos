//
//  SZHCV2.m
//  mapTestDemo
//
//  Created by 石子涵 on 2020/8/4.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "SZHCV2.h"
#import "RunLocationModel.h"
#import "MASmoothPathTool.h"

@interface SZHCV2 ()
@property (nonatomic, strong) MAMapView *mapView;
@property (nonatomic, strong) NSArray<MALonLatPoint*> *origTracePoints;     //原始轨迹测绘坐标点
@property (nonatomic, strong) NSArray<MALonLatPoint*> *smoothedTracePoints; //平滑处理用的轨迹数组点
@property (nonatomic, strong) NSMutableArray *mutebeAry;
@property (nonatomic, strong) MAPolyline *smoothedTrace;

@end

@implementation SZHCV2
    //将地图移动到定位中心点
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    MALonLatPoint *p = self.smoothedTracePoints.firstObject;
    if (p) {
        [self.mapView setCenterCoordinate:CLLocationCoordinate2DMake(p.lat, p.lon) animated:YES];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initMapView];
    [self loadTrancePoints];
    //这样写会将 self.originTracePoints设置为空数组
//    self.origTracePoints = [[NSArray alloc] init];
//    self.mutebeAry = [[NSMutableArray alloc] init];
    [self initSmoothedTrace];
}
- (void)initMapView{
    if (!self.mapView) {
        MAMapView *mapview = [[MAMapView alloc] initWithFrame:self.view.bounds];
        self.mapView = mapview;
        self.mapView.mapType = MAMapTypeStandard; //设置地图类型
        self.mapView.zoomLevel = 18;
        self.mapView.showsUserLocation = NO; //是否显示用户小蓝点
        self.mapView.pausesLocationUpdatesAutomatically = NO;
        self.mapView.showsCompass = NO;
        self.mapView.showsScale = NO;
        self.mapView.userInteractionEnabled = YES;
        //自定义用户位置小蓝点
        MAUserLocationRepresentation *r = [[MAUserLocationRepresentation alloc] init];
        r.showsAccuracyRing = NO; //不显示精度圈
        [self.mapView updateUserLocationRepresentation:r];
        
        [self.view addSubview:self.mapView];
        NSLog(@"地图已经加载");
    }
}

#pragma mark- 轨迹相关
 //因为CLLocationCoordinate2D为只读属性，无法用可变数组直接addobject储存，所以需要以下转化
- (void)loadTrancePoints{
    NSMutableArray *muteableAry = [NSMutableArray array];
    self.mutebeAry = muteableAry;
    //    CLLocationCoordinate2D linePoints[self.drawLineAry.count];
        for (int i = 0; i < self.drawLineAry.count; i++) {
            RunLocationModel *lineLocationModel = self.drawLineAry[i];
    //        linePoints[i] = lineLocationModel.location;
            MALonLatPoint *point = [[MALonLatPoint alloc] init];
            point.lat = lineLocationModel.location.latitude;
            point.lon = lineLocationModel.location.longitude;
            [self.mutebeAry addObject:point];
        }
    self.origTracePoints = self.mutebeAry;
    NSLog(@"绘制轨迹数组个数%lu",(unsigned long)self.origTracePoints.count);
}
//轨迹处理
//处理、绘制轨迹线
- (void)initSmoothedTrace{
    
    MASmoothPathTool *tool = [[MASmoothPathTool alloc] init];
    tool.intensity = 3;
    tool.threshHold = 0.3;
    tool.noiseThreshhold = 10;
    
    self.smoothedTracePoints = [tool pathOptimize:self.origTracePoints];
 NSLog(@"第二个界面的原始测绘的位置数组内元素个数为%lu",(unsigned long)self.origTracePoints.count);
    
    CLLocationCoordinate2D *pCoords = malloc(sizeof(CLLocationCoordinate2D) * self.smoothedTracePoints.count);
    if(!pCoords) {
        return;
    }

    for(int i = 0; i < self.smoothedTracePoints.count; ++i) {
        MALonLatPoint *p = [self.smoothedTracePoints objectAtIndex:i];
        CLLocationCoordinate2D *pCur = pCoords + i;
        pCur->latitude = p.lat;
        pCur->longitude = p.lon;
         NSLog(@"%f,%f",p.lat,p.lon);
    }

    self.smoothedTrace = [MAPolyline polylineWithCoordinates:pCoords count:self.smoothedTracePoints.count];
    [self.mapView addOverlay:self.smoothedTrace];
     NSLog(@"第二个界面处理过的轨迹测绘数组内的元素%lu",(unsigned long)self.smoothedTracePoints.count);
    if(pCoords) {
        free(pCoords);
    }
}

//自定义轨迹线
- (MAOverlayRenderer *)mapView:(MAMapView *)mapView rendererForOverlay:(id<MAOverlay>)overlay{
   if ([overlay isKindOfClass:[MAPolyline class]]) {
            MAPolylineRenderer *polyLineRender = [[MAPolylineRenderer alloc] initWithPolyline:overlay];
            polyLineRender.lineWidth = 8;
            polyLineRender.strokeColor = [UIColor colorWithRed:123/255.0 green:183/255.0 blue:196/255.0 alpha:1.0]; //折线颜色
      }
        return nil;
}
@end
