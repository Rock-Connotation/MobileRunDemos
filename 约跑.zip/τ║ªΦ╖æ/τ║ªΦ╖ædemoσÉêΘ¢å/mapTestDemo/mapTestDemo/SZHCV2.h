//
//  SZHCV2.h
//  mapTestDemo
//
//  Created by 石子涵 on 2020/8/4.
//  Copyright © 2020 石子涵. All rights reserved.
//
#import <MAMapKit/MAMapKit.h>
#import <AMapFoundationKit/AMapFoundationKit.h>
#import <MapKit/MapKit.h>
#import <AMapLocationKit/AMapLocationKit.h>
#import <Masonry.h>

NS_ASSUME_NONNULL_BEGIN

@interface SZHCV2 : UIViewController
@property (nonatomic, strong) NSArray *locationAry;
@property (nonatomic, strong) NSArray *drawLineAry;

@end

NS_ASSUME_NONNULL_END
