//
//  RunLocationModel.m
//  mapTestDemo
//
//  Created by 石子涵 on 2020/8/4.
//  Copyright © 2020 石子涵. All rights reserved.
//

#import "RunLocationModel.h"

@implementation RunLocationModel

@end
